package be.dzenali.gamification.data;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;


public class CoordsTest {

    Coords p1 = new Coords(10, 5);
    Coords p2 = new Coords(10, 5);
    Coords p3 = new Coords(10, 0);
    Coords p4 = new Coords(13, 9);
    Coords p5 = new Coords(0, 10);

    @Test
    void testGetDistanceToDistant() {
        double distance = p1.getDistanceTo(p4);
        double distance2 = p4.getDistanceTo(p1);
        assertEquals(5, distance);
        assertEquals(5, distance2);
    }

    @Test
    void testGetDistanceToSamePlace() {
        double distance = p1.getDistanceTo(p2);
        assertEquals(0, distance);
    }

    @Test
    void testGetDistanceSameCol() {
        double distance = p1.getDistanceTo(p3);
        assertEquals(5, distance);
    }

    @Test
    void testGetDistanceToSamePoint() {
        double distance = p1.getDistanceTo(p1);
        assertEquals(0, distance);
    }

    @Test
    void testGetAngleToDistant() {
        double angle = p3.getAngleTo(p5);
        double angle2 = p5.getAngleTo(p3);
//        assertEquals(90, angle);
        assertEquals(45, angle2);
    }

    @Test
    void testGetAngleToSamePlace() {
        double angle = p1.getAngleTo(p2);
        assertEquals(90, angle);
    }

    @Test
    void testGetAngleToSamePoint() {
        double angle = p1.getAngleTo(p1);
        assertEquals(90, angle);
    }

    @Test
    void testMoveClassic() {
        p1.move(5, 10);
        assertEquals(15, p1.getX());
        assertEquals(15, p1.getY());
    }

    @Test
    void testMove0() {
        p1.move(0, 0);
        assertEquals(10, p1.getX());
        assertEquals(5, p1.getY());
    }


}