package be.dzenali.gamification.entity.monster;

import be.dzenali.gamification.data.Aggressivity;
import org.junit.Test;
import org.junit.jupiter.api.Assertions;

public class DragonTest {

    @Test
    public void testDragon() {
        Dragon dragon = new Dragon();

        Assertions.assertEquals("Dragon", dragon.getName());
        Assertions.assertEquals(270, dragon.getHealthPoints().getCurrentHP());
        Assertions.assertEquals(270, dragon.getHealthPoints().getMaxHP());
        Assertions.assertEquals(72, dragon.getAttackDmg());
        Assertions.assertEquals(10, dragon.getArmorClass());
        Assertions.assertEquals(Aggressivity.HIGH, dragon.getAggressivity());
    }

    @Test
    public void testDragonFlying() {
        Dragon dragon = new Dragon();

        Assertions.assertTrue(dragon.canFly());
        Assertions.assertEquals(72, dragon.getAttackDmg());
        Assertions.assertEquals(10, dragon.getArmorClass());

        dragon.getHealthPoints().updateCurrentHP(-150);

        Assertions.assertFalse(dragon.canFly());
        Assertions.assertEquals(36, dragon.getAttackDmg()); // 72 * 0.5
        Assertions.assertEquals(15, dragon.getArmorClass()); // 10 * 1.5
    }

    @Test
    public void testDragonCannotFlying() {
        Dragon dragon = new Dragon();

        Assertions.assertTrue(dragon.canFly());

        dragon.getHealthPoints().updateCurrentHP(-10);

        Assertions.assertTrue(dragon.canFly());
    }
}