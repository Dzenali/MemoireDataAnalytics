package be.dzenali.gamification.entity;

import be.dzenali.gamification.builders.PlayerBuilder;
import be.dzenali.gamification.data.StatType;
import org.junit.Test;
import org.junit.jupiter.api.Assertions;


public class PlayerTest {

    @Test
    public void testPlayer() {
        PlayerBuilder playerBuilder = new PlayerBuilder();
        Player player = playerBuilder.build();

        Assertions.assertEquals("Player", player.getName());
        Assertions.assertEquals(1, player.getLevel());
        Assertions.assertEquals(120, player.getHealthPoints().getCurrentHP());
        Assertions.assertEquals(120, player.getHealthPoints().getMaxHP());
        Assertions.assertEquals(14, player.getArmorClass());
    }

    @Test
    public void testPlayerLevelUp() {
        PlayerBuilder playerBuilder = new PlayerBuilder();
        Player player = playerBuilder.build();

        player.gainExperience(100);

        Assertions.assertEquals(1, player.getLevel());
        Assertions.assertFalse(player.getHealthPoints().getMaxHP() > 120);
        Assertions.assertFalse(player.getArmorClass() > 14);
    }

    @Test
    public void testPlayerString() {
        PlayerBuilder playerBuilder = new PlayerBuilder();
        Player player = playerBuilder.build();

        String expectedString = "Player (Lvl 1) - HP: 120/120, Mana/Rage/energy: 0";
        Assertions.assertEquals(expectedString, player.toString());
    }

    @Test
    public void testLevelUp() {
        PlayerBuilder playerBuilder = new PlayerBuilder();
        Player player = playerBuilder.build();

        player.levelUp(StatType.CONSTITUTION);

        Assertions.assertEquals(2, player.getLevel());
    }

}