package be.dzenali.gamification.entity;

import be.dzenali.gamification.data.Aggressivity;
import be.dzenali.gamification.data.StatBlock;
import be.dzenali.gamification.data.StatType;
import org.junit.Test;
import org.junit.jupiter.api.Assertions;

public class MonsterTest {

    @Test
    public void testMonsterCreation() {
        Monster monster = new Monster("TestMonster", 1, new StatBlock(1,1,1,1,1,1), 10, 10, Aggressivity.HIGH, 100);

        Assertions.assertEquals("TestMonster", monster.getName());
        Assertions.assertEquals(1, monster.getHealthPoints().getCurrentHP());
        Assertions.assertEquals(1, monster.getHealthPoints().getMaxHP());
        Assertions.assertEquals(20, monster.getAttackDmg());
        Assertions.assertEquals(5, monster.getArmorClass());
        Assertions.assertEquals(Aggressivity.HIGH, monster.getAggressivity());
        Assertions.assertTrue(monster.isAlive());
    }

    @Test
    public void testMonster() {
        Monster monster = new Monster("TestMonster", 1, new StatBlock(1,1,1,1,1,1), 10, 10, Aggressivity.HIGH, 100);

        Assertions.assertEquals(Aggressivity.HIGH, monster.getAggressivity());

        monster.changeAggressivity(Aggressivity.LOW);

        Assertions.assertEquals(Aggressivity.LOW, monster.getAggressivity());
    }

    @Test
    public void testMonsterDeath() {
        Monster monster = new Monster("TestMonster", 1, new StatBlock(1,1,1,1,1,1), 10, 10, Aggressivity.HIGH, 100);

        Assertions.assertTrue(monster.isAlive());

        monster.getHealthPoints().updateCurrentHP(-1);

        Assertions.assertFalse(monster.isAlive());
    }

    @Test
    public void testMonsterDamage() {
        Monster monster = new Monster("TestMonster", 1, new StatBlock(1,1,1,1,1,1), 10, 10, Aggressivity.HIGH, 100);

        int damage = monster.getAttackDmg();

        Assertions.assertEquals(20, damage);
    }

    @Test
    public void testGetStats() {
        StatBlock stats = new StatBlock(1,2,3,4,5,6);
        Monster monster = new Monster("TestMonster", 1, stats, 10, 10, Aggressivity.HIGH, 100);

        Assertions.assertEquals(stats, monster.getStatBlock());
    }

    @Test
    public void testGetStat() {
        StatBlock stats = new StatBlock(1,2,3,4,5,6);
        Monster monster = new Monster("TestMonster", 1, stats, 10, 10, Aggressivity.HIGH, 100);

        Assertions.assertEquals(1, monster.getStat(StatType.STRENGTH));
        Assertions.assertEquals(2, monster.getStat(StatType.DEXTERITY));
        Assertions.assertEquals(3, monster.getStat(StatType.CONSTITUTION));
        Assertions.assertEquals(4, monster.getStat(StatType.INTELLIGENCE));
        Assertions.assertEquals(5, monster.getStat(StatType.WISDOM));
        Assertions.assertEquals(6, monster.getStat(StatType.CHARISMA));
    }

    @Test
    public void testGetExp() {
        Monster monster = new Monster("TestMonster", 1, new StatBlock(1,1,1,1,1,1), 10, 10, Aggressivity.HIGH, 100);

        Assertions.assertEquals(100, monster.getExp());
    }

    @Test
    public void testString() {
        Monster monster = new Monster("TestMonster", 1, new StatBlock(1,1,1,1,1,1), 10, 10, Aggressivity.HIGH, 100);

        String expectedString = "TestMonster - HP: 1/1";
        Assertions.assertEquals(expectedString, monster.toString());
    }

}