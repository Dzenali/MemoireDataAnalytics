package be.dzenali.gamification.entity.monster;

import org.junit.Test;
import org.junit.jupiter.api.Assertions;

public class OrkTest {

    @Test
    public void testOrk() {
        Ork ork = new Ork();

        Assertions.assertEquals("Ork", ork.getName());
        Assertions.assertEquals(42, ork.getHealthPoints().getCurrentHP());
        Assertions.assertEquals(42, ork.getHealthPoints().getMaxHP());
        Assertions.assertEquals(12, ork.getAttackDmg());
        Assertions.assertEquals(12, ork.getArmorClass());
    }

    @Test
    public void ironWillTest() {
        Ork ork = new Ork();

        Assertions.assertFalse(ork.ironWillIsActive());
        Assertions.assertEquals(12, ork.getAttackDmg());
        Assertions.assertEquals(12, ork.getArmorClass());

        ork.ironWill();

        Assertions.assertTrue(ork.ironWillIsActive());
        Assertions.assertEquals(15, ork.getAttackDmg());
        Assertions.assertEquals(18, ork.getArmorClass());

        ork.ironWill();

        Assertions.assertFalse(ork.ironWillIsActive());
        Assertions.assertEquals(12, ork.getAttackDmg());
        Assertions.assertEquals(12, ork.getArmorClass());
    }
}