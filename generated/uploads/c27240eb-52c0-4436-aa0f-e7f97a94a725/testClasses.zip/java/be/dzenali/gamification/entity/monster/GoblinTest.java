package be.dzenali.gamification.entity.monster;

import org.junit.Test;
import org.junit.jupiter.api.Assertions;

public class GoblinTest {

    @Test
    public void testGoblin() {
        Goblin goblin = new Goblin();

        Assertions.assertEquals("Goblin", goblin.getName());
        Assertions.assertEquals(4, goblin.getHealthPoints().getCurrentHP());
        Assertions.assertEquals(4, goblin.getHealthPoints().getMaxHP());
        Assertions.assertEquals(5, goblin.getAttackDmg());
        Assertions.assertEquals(5, goblin.getArmorClass());
    }


}