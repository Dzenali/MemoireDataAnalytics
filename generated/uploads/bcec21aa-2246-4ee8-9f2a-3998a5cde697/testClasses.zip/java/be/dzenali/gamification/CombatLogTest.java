package be.dzenali.gamification;


import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import java.util.List;
import static org.junit.jupiter.api.Assertions.*;

//import org.junit.Test;

public class CombatLogTest {
    private CombatLog combatLog;

    @BeforeEach
    void setUp() {
        combatLog = new CombatLog();
    }

    @Test
    void testLogAddsEntryWithCorrectFormat() {
        String message = "Le guerrier attaque le dragon";

        combatLog.log(message);
        List<String> logs = combatLog.getLogs();


        assertEquals(1, logs.size(), "Le log devrait contenir exactement une entrée.");

        String logEntry = logs.get(0);

        assertTrue(logEntry.contains(message), "L'entrée de log doit contenir le message original.");
        assertTrue(logEntry.matches("\\[\\d{2}:\\d{2}:\\d{2}\\] .*"), "Le format du timestamp doit être [HH:mm:ss].");
    }


    @Test
    public void testClearEmptyLogs() {
        combatLog.log("Action 1");
        combatLog.log("Action 2");
        assertEquals(2, combatLog.getLogs().size());

        combatLog.clear();

        assertTrue(combatLog.getLogs().isEmpty(), "La liste des logs devrait être vide après un clear().");
    }

    @Test
    void testGetLogsReturnsCopyNotReference() {
        combatLog.log("Message initial");


        List<String> logsFromGetter = combatLog.getLogs();
        logsFromGetter.add("Tentative de modification externe");

        assertEquals(1, combatLog.getLogs().size(),
                "La liste interne ne doit pas être modifiable depuis l'extérieur (encapsulation).");
    }

    /* pas de mutants dans cette classe  @Test
    void testLogSequenceAndPersistence() {
        // Arrange
        String firstAction = "L'archer tire une flèche";
        String secondAction = "Le gobelin esquive";

        combatLog.log(firstAction);
        combatLog.log(secondAction);
        List<String> logs = combatLog.getLogs();

        assertEquals(2, logs.size(), "Le log doit contenir exactement 2 entrées.");

        assertTrue(logs.get(0).contains(firstAction), "La première entrée doit correspondre au premier message envoyé.");
        assertTrue(logs.get(1).contains(secondAction), "La deuxième entrée doit correspondre au second message envoyé.");

        String expectedSuffix = "] " + secondAction;
        assertTrue(logs.get(1).endsWith(expectedSuffix), "L'entrée de log doit se terminer exactement par le message fourni.");
    }*/
}