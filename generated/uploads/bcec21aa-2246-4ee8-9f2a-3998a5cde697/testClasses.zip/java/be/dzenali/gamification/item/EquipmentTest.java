package be.dzenali.gamification.item;
import be.dzenali.gamification.data.ArmorType;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import java.util.List;
import static org.junit.jupiter.api.Assertions.*;

public class EquipmentTest {
    @Test
   public void testEquipmentInitialization() {

        int initialDurability = 50;
        int value = 100;

        Equipment equipment = new Equipment(initialDurability, value);

        assertEquals(50, equipment.getDurability());
        assertEquals(50, equipment.getMaxDurability());
        assertFalse(equipment.isBroken());
    }

    @Test
    void testIsBroken_KillsBoundaryMutants() {
        Equipment equipment = new Equipment(10, 100);

        //j'amène la durabilité à exactement 0
        equipment.updateDurability(-10);

        // j'assert apres
        assertTrue(equipment.isBroken(), "L'équipement doiy être brisé quand la durabilité est à 0.");
        assertEquals(0, equipment.getDurability(), "getDurability() devrait retourner 0 même si la valeur interne est <= 0.");
    }

    @Test
    void testFullCoverage() {
            // Couvre : Equipment(), getValue(), getMaxDurability()
            Equipment item = new Equipment(50, 100);

            assertEquals(100, item.getValue());
            assertEquals(50, item.getMaxDurability());


            assertFalse(item.isBroken(), "L'item ne devrait pas être brisé au départ.");
            assertEquals(50, item.getDurability(), "Doit retourner la durabilité réelle si > 0.");


            item.updateDurability(-10);
            assertEquals(40, item.getDurability());


            item.updateDurability(-40); // On tombe à 0
            assertTrue(item.isBroken(), "L'item doit être brisé à 0.");
            assertEquals(0, item.getDurability(), "getDurability doit retourner 0 quand isBroken est true.");

            item.updateDurability(-10); // On tombe à -10
            assertTrue(item.isBroken());
            assertEquals(0, item.getDurability(), "Même en négatif, l'affichage doit être 0.");
        }

}