package be.dzenali.gamification.item;
import be.dzenali.gamification.data.ArmorType;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import java.util.List;
import static org.junit.jupiter.api.Assertions.*;

public class ArmorTest {
    @Test
    void testArmorClass_MediumArmor() {
        Armor mediumArmor = new Armor(15, ArmorType.MEDIUM, 100, 500);

        int cap = mediumArmor.getArmorClassDexBonusCap();

        assertEquals(3, cap, "Le cap de dextérité pour une armure MEDIUM doit être de 3.");
    }

    @Test
    void testDamageDurability_KillsLightArmorMutants() {
        int initialDurability = 100;
        Armor lightArmor = new Armor(12, ArmorType.LIGHT, initialDurability, 100);
        int damageTaken = 10;

        lightArmor.damageDurability(damageTaken);

        //On s'attend à une réduction de 10 * 0.5 = 5 points
        int expectedDurability = initialDurability - 5;
        assertEquals(expectedDurability, lightArmor.getDurability(),
                "Une armure LIGHT devrait subir 50% des dégâts reçus sur sa durabilité.");
    }

    @Test
    void testArmorClass_WhenBroken() {
        Armor dyingArmor = new Armor(20, ArmorType.HEAVY, 1, 1000);

        assertFalse(dyingArmor.isBroken());
        assertEquals(20, dyingArmor.getArmorClass(), "L'armure intacte doit retourner sa classe d'armure réelle.");

        dyingArmor.damageDurability(2);

        assertTrue(dyingArmor.isBroken(), "L'armure devrait être considérée comme brisée.");
        assertEquals(10, dyingArmor.getArmorClass(), "Une armure brisée doit toujours retourner une AC de 10.");
    }
}