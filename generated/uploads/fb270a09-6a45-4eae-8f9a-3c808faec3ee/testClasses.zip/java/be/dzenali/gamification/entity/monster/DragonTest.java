package be.dzenali.gamification.entity.monster;

import be.dzenali.gamification.entity.Monster;
import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.*;

public class DragonTest {

    private Dragon dragon;

    @Before
    public void setUp() {
        dragon = new Dragon();
    }

    @Test
    public void shouldHaveCorrectDefaultValues() {
        assertEquals("Dragon", dragon.getName());
        assertEquals(5000, dragon.getExp());

        assertEquals(18, dragon.getStat(be.dzenali.gamification.data.StatType.STRENGTH));
    }

    @Test
    public void shouldBeAbleToFlyAtStart() {
        assertTrue(dragon.canFly());
    }

    @Test
    public void shouldUseNormalAttackWhenFlying() {
        int expected = dragon.getAttackDmg();

        assertEquals(expected, dragon.getAttackDmg());
    }


    @Test
    public void shouldKeepNormalArmorWhenFlying() {
        int armor1 = dragon.getArmorClass();
        int armor2 = dragon.getArmorClass();

        assertEquals(armor1, armor2);
    }
}