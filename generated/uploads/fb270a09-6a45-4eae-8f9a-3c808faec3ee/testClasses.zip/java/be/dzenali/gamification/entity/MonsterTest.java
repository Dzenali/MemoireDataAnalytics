package be.dzenali.gamification.entity;

import be.dzenali.gamification.builders.MonsterBuilder;
import be.dzenali.gamification.data.Aggressivity;
import be.dzenali.gamification.data.StatType;
import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.assertEquals;

public class MonsterTest {

    private MonsterBuilder builder;

    @Before
    public void setUp() {
        builder = new MonsterBuilder();
    }

    @Test
    public void testExample() {
        Monster monster = builder
                .setName("Goblin")
                .setName(2)
                .setStat(StatType.CONSTITUTION, 10)
                .setStat(StatType.STRENGTH, 8)
                .setAttack(12)
                .setArmorClass(7)
                .setAggressivity(Aggressivity.MEDIUM)
                .setExp(100)
                .build();

        assertEquals("Goblin", monster.getName());
    }

    @Test
    public void getAttackDmg() {
        Monster monster = builder
                .setAttack(12)
                .setAggressivity(Aggressivity.MEDIUM)
                .build();

        int expected = (int) (12 * Aggressivity.MEDIUM.getMultiplier());
        assertEquals(expected, monster.getAttackDmg());
    }
    @Test
    public void getArmorClass() {
        Monster monster = builder
                .setArmorClass(6)
                .setAggressivity(Aggressivity.MEDIUM)
                .build();

        int expected = (int) (6 / Aggressivity.MEDIUM.getMultiplier());
        assertEquals(expected, monster.getArmorClass());
    }
    @Test
    public void getExp() {
        Monster monster = builder
                .setExp(8)
                .build();

        assertEquals(8, monster.getExp());
    }
    @Test
    public void getAggressivity() {
        Monster monster = builder
                .setAggressivity(Aggressivity.MEDIUM)
                .build();

        int expected = (int) (Aggressivity.MEDIUM.getMultiplier());
        assertEquals(expected, monster.getAggressivity().getMultiplier(),1);
    }
}