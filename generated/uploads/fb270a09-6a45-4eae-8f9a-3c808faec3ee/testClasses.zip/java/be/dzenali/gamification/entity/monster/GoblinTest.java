package be.dzenali.gamification.entity.monster;

import be.dzenali.gamification.data.Aggressivity;
import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.assertEquals;

public class GoblinTest {

    private Goblin goblin;

    @Before
    public void setUp() {
        goblin = new Goblin();
    }

    @Test
    public void shouldHaveCorrectDefaultValues() {
        assertEquals("Goblin", goblin.getName());
        assertEquals(50, goblin.getExp());
        assertEquals(Aggressivity.MEDIUM, goblin.getAggressivity());
        assertEquals(5, goblin.getAttackDmg());
        assertEquals(5, goblin.getArmorClass());
        assertEquals(6, goblin.getStat(be.dzenali.gamification.data.StatType.STRENGTH));
    }
}