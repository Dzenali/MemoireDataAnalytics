package be.dzenali.gamification.entity.monster;

import org.junit.Test;

public class DragonTest {

    @Test
    public void canFly(){
        Dragon dragon = new Dragon();
        assert(dragon.canFly());
        dragon.getHealthPoints().updateCurrentHP(-150);
        assert (!dragon.canFly());
    }

}