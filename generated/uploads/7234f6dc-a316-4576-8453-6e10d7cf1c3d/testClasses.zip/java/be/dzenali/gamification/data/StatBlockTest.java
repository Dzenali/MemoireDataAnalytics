package be.dzenali.gamification.data;

import org.junit.Test;

public class StatBlockTest {

    @Test
    public void getTest(){
        StatBlock statBlock = new StatBlock(-10, 12, 14, 8, 16, 19);
        assert(statBlock.get(StatType.STRENGTH) == 1);
        assert(statBlock.get(StatType.DEXTERITY) == 12);
        assert(statBlock.get(StatType.CONSTITUTION) == 14);
        assert(statBlock.get(StatType.INTELLIGENCE) == 8);
        assert(statBlock.get(StatType.WISDOM) == 16);
        assert(statBlock.get(StatType.CHARISMA) == 18);
    }

    @Test
    public void increaseTest(){
        StatBlock statBlock = new StatBlock(10, 12, 14, 8, 16, 18);
        statBlock.increase(StatType.STRENGTH);
        assert(statBlock.get(StatType.STRENGTH) == 11);
        statBlock.increase(StatType.CHARISMA);
        assert(statBlock.get(StatType.CHARISMA) == 19);
        statBlock.increase(StatType.CHARISMA);
        assert(statBlock.get(StatType.CHARISMA) == 20);
        statBlock.increase(StatType.CHARISMA);
        assert(statBlock.get(StatType.CHARISMA) == 20);
    }


}