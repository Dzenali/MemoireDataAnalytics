package be.dzenali.gamification.data;

import org.junit.Test;

public class CoordsTest {

    @Test
    public void gettersTest(){
        Coords coords = new Coords(1, 2);
        assert(coords.getX() == 1);
        assert(coords.getY() == 2);
    }

    @Test
    public void settersTest(){
        Coords coords = new Coords(1, 2);
        coords.setX(3);
        coords.setY(4);
        assert(coords.getX() == 3);
        assert(coords.getY() == 4);
    }

    @Test
    public void getDistanceToTest(){
        Coords coords1 = new Coords(0, 0);
        Coords coords2 = new Coords(0, 4);
        assert(coords1.getDistanceTo(coords2) == 4);
    }

    @Test
    public void getAngleToTest(){
        Coords coords1 = new Coords(0, 0);
        Coords coords2 = new Coords(0, 4);
        assert(coords1.getAngleTo(coords2) == 90);
    }

    @Test
    public void moveTest(){
        Coords coords = new Coords(1, 2);
        coords.move(1, 1);
        assert(coords.getX() == 2);
        assert(coords.getY() == 1);
    }

}