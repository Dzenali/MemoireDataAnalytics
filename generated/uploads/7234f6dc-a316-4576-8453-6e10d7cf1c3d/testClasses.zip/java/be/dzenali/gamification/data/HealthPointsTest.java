package be.dzenali.gamification.data;

import org.junit.Test;

public class HealthPointsTest {

    @Test
    public void constructorTest(){
        HealthPoints healthPoints = new HealthPoints(10, 20);
        assert healthPoints.getCurrentHP() == 10;
        assert healthPoints.getMaxHP() == 20;
    }

    @Test
    public void constructorTest2(){
        HealthPoints healthPoints = new HealthPoints(30, 20);
        assert healthPoints.getCurrentHP() == 20;
        assert healthPoints.getMaxHP() == 20;
    }

    @Test
    public void constructorTest3(){
        HealthPoints healthPoints = new HealthPoints(-10, 20);
        assert healthPoints.getCurrentHP() == 1;
        assert healthPoints.getMaxHP() == 20;
    }

    @Test
    public void constructorTest4(){
        HealthPoints healthPoints = new HealthPoints(10, -20);
        assert healthPoints.getCurrentHP() == 1;
        assert healthPoints.getMaxHP() == 1;
    }

    @Test
    public void increasedByTest(){
        HealthPoints healthPoints = new HealthPoints(10, 20);
        HealthPoints result = healthPoints.increasedBy(new HealthPoints(5, 10));
        assert result.getCurrentHP() == 15;
        assert result.getMaxHP() == 30;
    }

    @Test
    public void updateCurrentHpTest(){
        HealthPoints healthPoints = new HealthPoints(10, 20);
        healthPoints.updateCurrentHP(5);
        assert healthPoints.getCurrentHP() == 15;
        healthPoints.updateCurrentHP(-20);
        assert healthPoints.getCurrentHP() == 0;
    }

}