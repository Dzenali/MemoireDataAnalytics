package be.dzenali.gamification.item;

import be.dzenali.gamification.data.ArmorType;
import org.junit.Test;

public class ArmorTest {

    @Test
    public void getArmorClassTest(){
        Armor armor = new Armor(15, ArmorType.HEAVY, 100, 200);
        assert armor.getArmorClass() == 15;
    }

    @Test
    public void getArmorType(){
        Armor armor = new Armor(15, ArmorType.HEAVY, 100, 200);
        assert armor.getArmorType() == ArmorType.HEAVY;
    }

    @Test
    public void damageDurabilityTest(){
        Armor armor = new Armor(15, ArmorType.HEAVY, 100, 200);
        armor.damageDurability(20);
        assert armor.getDurability() == 130;
    }

    @Test
    public void getArmorClassDexBonusCapTest(){
        Armor armor = new Armor(15, ArmorType.HEAVY, 100, 200);
        assert armor.getArmorClassDexBonusCap() == 0;
        Armor armor1 = new Armor(15, ArmorType.MEDIUM, 100, 200);
        assert armor1.getArmorClassDexBonusCap() == 3;
        Armor armor2 = new Armor(15, ArmorType.LIGHT, 100, 200);
        assert armor2.getArmorClassDexBonusCap() == 5;
    }

    @Test
    public void toStringTest(){
        Armor armor = new Armor(15, ArmorType.HEAVY, 100, 200);
        String expected = "damage: 15, durability: 100, armor type: HEAVY, value: 200";
        assert armor.toString().equals(expected);
    }

}