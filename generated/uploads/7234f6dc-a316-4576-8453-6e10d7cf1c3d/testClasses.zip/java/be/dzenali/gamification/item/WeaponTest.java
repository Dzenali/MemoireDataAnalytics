package be.dzenali.gamification.item;

import be.dzenali.gamification.data.WeaponType;
import org.junit.Test;

public class WeaponTest {

    @Test
    public void getWeaponDamageTest(){
        Weapon weapon = new Weapon(10, WeaponType.HEAVY, 10, 100);
        assert weapon.getWeaponDamage() == 10;
        weapon.damageDurability(-10);
        assert weapon.getWeaponDamage() == 0;
    }

    @Test
    public void getWeaponTypeTest(){
        Weapon weapon = new Weapon(10, WeaponType.HEAVY, 10, 100);
        assert weapon.getWeaponType() == WeaponType.HEAVY;
    }

     @Test
     public void toStringTest(){
         Weapon weapon = new Weapon(10, WeaponType.HEAVY, 10, 100);
         String expected = "damage: 10, durability: 10, value: 100";
         assert weapon.toString().equals(expected);
     }

     @Test
    public void damageDurabilityTest(){
        Weapon weapon = new Weapon(10, WeaponType.HEAVY, 10, 100);
        weapon.damageDurability(5);
        assert weapon.getDurability() == 15;
     }

}