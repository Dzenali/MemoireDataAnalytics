package be.dzenali.gamification.entity;

import be.dzenali.gamification.data.Aggressivity;
import be.dzenali.gamification.data.StatBlock;
import be.dzenali.gamification.data.StatType;
import org.junit.Test;

public class MonsterTest {

    @Test
    public void getters(){
        Monster monster = new Monster("Test", 3, new StatBlock(10,10,10,10,10,10), 5, 15, Aggressivity.HIGH, 100);
        assert monster.getName().equals("Test");
        assert monster.getStat(StatType.CONSTITUTION) == 10;
        assert monster.getStatBlock().get(StatType.CONSTITUTION) == 10;
        assert monster.getAttackDmg() == 10;
        assert monster.getArmorClass() == 7;
        assert monster.getAggressivity() == Aggressivity.HIGH;
        assert monster.getExp() == 100;
    }

    @Test
    public void isAlive(){
        Monster monster = new Monster("Test", 3, new StatBlock(10,10,10,10,10,10), 5, 15, Aggressivity.HIGH, 100);
        assert monster.isAlive();

    }

    @Test
    public void changeAgressivityTest(){
        Monster monster = new Monster("Test", 3, new StatBlock(10,10,10,10,10,10), 5, 15, Aggressivity.HIGH, 100);
        assert monster.getAggressivity() == Aggressivity.HIGH;
        monster.changeAggressivity(Aggressivity.LOW);
        assert monster.getAggressivity() == Aggressivity.LOW;
    }

    @Test
    public void toStringTest(){
        Monster monster = new Monster("Test", 3, new StatBlock(10,10,10,10,10,10), 5, 15, Aggressivity.HIGH, 100);
        String toString = "Test - HP: 30/30";
        assert monster.toString().equals(toString);
    }
    
}