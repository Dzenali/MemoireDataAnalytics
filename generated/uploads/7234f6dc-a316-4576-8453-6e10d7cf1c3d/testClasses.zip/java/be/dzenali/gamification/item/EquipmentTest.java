package be.dzenali.gamification.item;

import org.junit.Test;

public class EquipmentTest {

    @Test
    public void isBrokenTest(){
        Equipment equipment = new Equipment(0, 100);
        assert equipment.isBroken();
        Equipment equipment1 = new Equipment(10, 100);
        assert !equipment1.isBroken();
    }

    @Test
    public void updateDurabilityTest(){
        Equipment equipment = new Equipment(10, 100);
        equipment.updateDurability(-5);
        assert equipment.getDurability() == 5;
        equipment.updateDurability(-10);
        assert equipment.getDurability() == 0;
    }

    @Test
    public void gettersTest(){
        Equipment equipment = new Equipment(10, 100);
        assert equipment.getDurability() == 10;
        assert equipment.getValue() == 100;
        assert equipment.getMaxDurability() == 10;
    }
}