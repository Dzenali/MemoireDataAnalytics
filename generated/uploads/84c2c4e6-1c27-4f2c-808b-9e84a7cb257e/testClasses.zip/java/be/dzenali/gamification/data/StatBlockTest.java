package be.dzenali.gamification.data;

import org.junit.Test;

public class StatBlockTest {

    @Test
    public void testConstructor() {
        StatBlock sb = new StatBlock(5,2,3,4,5,6);
        assert(sb.get(StatType.STRENGTH) == 5);
    }

    @Test
    public void testConstructor2() {
        StatBlock sb = new StatBlock(0,2,3,4,5,6);
        assert(sb.get(StatType.STRENGTH) == 1);
    }

    @Test
    public void testConstructor3() {
        StatBlock sb = new StatBlock(19,2,3,4,5,6);
        assert(sb.get(StatType.STRENGTH) == 18);
    }

    @Test
    public void testIncrease() {
        StatBlock sb = new StatBlock(1,2,3,4,5,6);
        sb.increase(StatType.DEXTERITY);
        assert(sb.get(StatType.DEXTERITY) == 3);
    }

    @Test
    public void testIncrease2() {
        StatBlock sb = new StatBlock(1,19,3,4,5,6);
        sb.increase(StatType.DEXTERITY);
        assert(sb.get(StatType.DEXTERITY) == 19);
    }
}