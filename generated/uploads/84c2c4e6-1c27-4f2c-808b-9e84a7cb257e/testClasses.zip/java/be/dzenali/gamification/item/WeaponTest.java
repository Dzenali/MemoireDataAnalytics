package be.dzenali.gamification.item;

import be.dzenali.gamification.data.WeaponType;
import org.junit.Test;

public class WeaponTest {

    @Test
    public void testGetWeaponDamage() {
        Weapon wp = new Weapon(5, WeaponType.HEAVY,50,500);
        assert(wp.getDamage() == 5);
    }

    @Test
    public void testGetWeaponDamage2() {
        Weapon wp = new Weapon(5, WeaponType.HEAVY,-1,500);
        assert(wp.getWeaponDamage() == 0);
    }

    @Test
    public void testGetWeaponType() {
        Weapon wp = new Weapon(5, WeaponType.HEAVY,-1,500);
        assert(wp.getWeaponType() == WeaponType.HEAVY);
    }

    @Test
    public void testDamageDurability() {
        Weapon wp = new Weapon(5, WeaponType.HEAVY,-1,500);
        wp.damageDurability(5);
        assert(wp.getDurability() == 4);
    }
}