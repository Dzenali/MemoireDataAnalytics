package be.dzenali.gamification.data;

import org.junit.Test;

public class HealthPointsTest {

    @Test
    public void testConstructor() {
        HealthPoints hp = new HealthPoints(50,-2);
        assert(hp.getMaxHP() == 1);
        assert(hp.getCurrentHP() == 1);
    }

    @Test
    public void testconstructor2() {
        HealthPoints hp = new HealthPoints(-5,20);
        assert(hp.getMaxHP() == 20);
        assert(hp.getCurrentHP() == 1);
    }

    @Test
    public void testConstructor3() {
        HealthPoints hp = new HealthPoints(5,20);
        assert(hp.getMaxHP() == 20);
        assert(hp.getCurrentHP() == 5);
    }

    @Test
    public void testIncreasedBy() {
        HealthPoints hp = new HealthPoints(5,20);
        HealthPoints hp2 = new HealthPoints(2,40);
        HealthPoints newHp =  hp.increasedBy(hp2);
        assert(newHp.getMaxHP() == 60);
        assert(newHp.getCurrentHP() == 7);
    }

    @Test
    public void testUpdateCurrentHP() {
        HealthPoints hp = new HealthPoints(5,20);
        int newCurrentHp = hp.updateCurrentHP(7);
        assert(newCurrentHp == 12);
    }

    @Test
    public void testUpdateCurrentHP2() {
        HealthPoints hp = new HealthPoints(5,20);
        hp.updateCurrentHP(20);
        assert(hp.getCurrentHP() == 20);
    }

    @Test
    public void testUpdateCurrentHP3() {
        HealthPoints hp = new HealthPoints(5,20);
        hp.updateCurrentHP(-7);
        assert(hp.getCurrentHP() == 0);
    }
}