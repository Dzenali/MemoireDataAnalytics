package be.dzenali.gamification.entity;

import be.dzenali.gamification.data.Aggressivity;
import be.dzenali.gamification.data.HealthPoints;
import be.dzenali.gamification.data.StatBlock;
import be.dzenali.gamification.data.StatType;
import org.junit.Test;

public class MonsterTest {

    @Test
    public void testGetStatBlock() {
        StatBlock sb = new StatBlock(1,2,3,4,5,6);
        Monster monster = new Monster("m",1,sb,2,3,Aggressivity.HIGH,4);
        assert(monster.getStatBlock() == sb);
    }

    @Test
    public void testGetAttackDmg() {
        StatBlock sb = new StatBlock(1,2,3,4,5,6);
        Monster monster = new Monster("m",1,sb,2,3,Aggressivity.HIGH,4);
        assert(monster.getAttackDmg() == 2*2);
    }

    @Test
    public void testArmorClass() {
        StatBlock sb = new StatBlock(1,2,3,4,5,6);
        Monster monster = new Monster("m",1,sb,2,3,Aggressivity.HIGH,4);
        assert(monster.getArmorClass() == 3/2);
    }

    @Test
    public void testChangeAggressivity() {
        StatBlock sb = new StatBlock(1,2,3,4,5,6);
        Monster monster = new Monster("m",1,sb,2,3,Aggressivity.HIGH,4);
        monster.changeAggressivity(Aggressivity.LOW);
        assert(monster.getAggressivity() == Aggressivity.LOW);
    }

    @Test
    public void testIsAlive() {
        StatBlock sb = new StatBlock(1,2,3,4,5,6);
        Monster monster = new Monster("m",1,sb,2,3,Aggressivity.HIGH,4);
        assert(monster.isAlive());
    }

    @Test
    public void testIsAlive2() {
        StatBlock sb = new StatBlock(1,2,3,4,5,6);
        Monster monster = new Monster("m",1,sb,2,3,Aggressivity.HIGH,4);
        monster.getHealthPoints().updateCurrentHP(-5);
        assert(!monster.isAlive());
    }

    @Test
    public void testConstructor() {
        StatBlock sb = new StatBlock(1,2,3,4,5,6);
        Monster monster = new Monster("m",1,sb,2,3,Aggressivity.HIGH,4);
        HealthPoints hp = new HealthPoints(3,3);
        assert(monster.getHealthPoints().getCurrentHP() == hp.getCurrentHP());
        assert(monster.getHealthPoints().getMaxHP() == hp.getMaxHP());
    }
}