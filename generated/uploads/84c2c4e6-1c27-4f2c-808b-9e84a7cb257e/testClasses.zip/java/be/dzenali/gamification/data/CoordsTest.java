package be.dzenali.gamification.data;

import org.junit.Test;

public class CoordsTest {

    @Test
    public void testGetDistanceTo() {
        Coords coords1 = new Coords(1,1);
        Coords coords2 = new Coords(1,2);
        double distance = coords1.getDistanceTo(coords2);
        assert(distance == 1);
    }

    @Test
    public void testGetAngleTo() {
        Coords coords1 = new Coords(1,1);
        Coords coords2 = new Coords(1,2);
        double angle = coords1.getAngleTo(coords2);
        assert(angle == 90);
    }

    @Test
    public void testMove() {
        Coords coords = new Coords(1,1);
        double oldX = coords.getX();
        double oldY = coords.getY();
        coords.move(1,2);
        double newX = coords.getX();
        double newY = coords.getY();
        assert(newX == oldX + 1);
        assert(newY == oldY - 2);
    }
}