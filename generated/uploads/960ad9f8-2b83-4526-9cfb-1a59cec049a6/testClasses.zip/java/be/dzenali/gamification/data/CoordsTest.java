package be.dzenali.gamification.data;

import org.junit.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class CoordsTest {
    @Test
    public void coordGetterTest(){
        Coords coordinates = new Coords(12,25);
        Double x = coordinates.getX();
        Double y = coordinates.getY();

        assertEquals(x,12);
        assertEquals(y,25);

    }

    @Test
    public void getDistanceToTest(){
        Coords coord = new Coords(12,25);
        Coords coordTo = new Coords(25,12);

        Double dist =  Math.sqrt(Math.pow(coordTo.getX() - coord.getX(), 2) + Math.pow(coordTo.getY() - coord.getY(), 2));

        assertEquals(coord.getDistanceTo(coordTo),dist);
        assertEquals(coordTo.getDistanceTo(coord),dist);
    }

    @Test
    public void getAngleToTest() {
        Coords coord = new Coords(12,25);
        Coords coordTo = new Coords(25,12);

        double deltaX = coordTo.getX() - coord.getX();
        double deltaY = coordTo.getY() + coord.getY();
        double angleRad = Math.atan2(deltaY, deltaX);
        double angeDeg = Math.toDegrees(angleRad);
        assertEquals(coord.getAngleTo(coordTo),angeDeg);
    }
    @Test
    public void movementTest() {
        Coords coord = new Coords(12,25);
        double xOffset = 3;
        double yOffset = 3;

        coord.move(xOffset,yOffset);
        assertEquals(coord.getX(),15);
        assertEquals(coord.getY(),22);



    }

}