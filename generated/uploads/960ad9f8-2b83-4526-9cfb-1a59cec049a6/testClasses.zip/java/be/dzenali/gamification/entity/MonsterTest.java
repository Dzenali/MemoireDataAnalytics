package be.dzenali.gamification.entity;

import be.dzenali.gamification.data.Aggressivity;
import be.dzenali.gamification.data.StatBlock;
import be.dzenali.gamification.entity.monster.Dragon;
import org.junit.jupiter.api.Test;

public class MonsterTest {

    @Test
    void testResource() {
        StatBlock rimuruStat = new StatBlock(20,20,20,20,20,20);
        Monster rimuru = new Monster("Limule", 100 ,rimuruStat, 36,
                20,
                Aggressivity.HIGH,
                5000);

    }
}