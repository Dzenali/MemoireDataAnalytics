package be.dzenali.gamification;

import org.junit.Test;

import java.util.ArrayList;
import java.util.List;

import static java.awt.geom.Path2D.contains;
import static org.hamcrest.MatcherAssert.assertThat;


public class CombatLogTest {

    @Test
    public void testLog() {

    }

}