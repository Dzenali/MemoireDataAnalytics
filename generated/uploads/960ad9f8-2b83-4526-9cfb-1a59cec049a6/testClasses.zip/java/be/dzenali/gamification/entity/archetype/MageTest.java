package be.dzenali.gamification.entity.archetype;

import org.junit.jupiter.api.Test;

import java.awt.*;
import java.util.HashSet;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class MageTest {

    @Test
    void testResource() {
        Mage merlin = new Mage();
        int initRes = merlin.getResource();

        assertEquals(initRes,300);

    }

    @Test
    void testSetResource() {
        Mage merlin = new Mage();
        merlin.setMana(800);
        assertEquals(merlin.getResource(),800);

    }

    @Test
    void testFireBallSpell() {
        Mage merlin = new Mage();
        int initRes = merlin.getResource();
        int damage = merlin.cast("FireBall");

        assertEquals(merlin.getResource(), initRes- 30);
        assertEquals(damage,65);

    }

    @Test
    void testFireBallSpellNoMana() {
        Mage merlin = new Mage();
        merlin.setMana(20);
        int initRes = merlin.getResource();
        int damage = merlin.cast("FireBall");
        assertEquals(merlin.getResource(), initRes);
        assertEquals(damage,0);
    }

    @Test
    void testFireBallSpellExact() {
        Mage merlin = new Mage();
        merlin.setMana(30);
        int damage = merlin.cast("FireBall");
        assertEquals(merlin.getResource(), 0);
        assertEquals(damage,65);
    }

    @Test
    void testIceSpearSpell() {
        Mage merlin = new Mage();
        int initRes = merlin.getResource();
        int damage = merlin.cast("IceSpear");
        assertEquals(damage,50);
        assertEquals(merlin.getResource(), initRes- 20);
    }

    @Test
    void testIceSpearSpellNoMana() {
        Mage merlin = new Mage();
        merlin.setMana(10);
        int initRes = merlin.getResource();
        int damage = merlin.cast("IceSpear");
        assertEquals(damage,0);
        assertEquals(merlin.getResource(), initRes);
    }

    @Test
    void testIceSpearSpellExact() {
        Mage merlin = new Mage();
        merlin.setMana(20);
        int damage = merlin.cast("IceSpear");
        assertEquals(merlin.getResource(), 0);
        assertEquals(damage,50);
    }


    @Test
    void testHealSpell() {
        Mage merlin = new Mage();
        int initRes = merlin.getResource();
        int damage = merlin.cast("Heal");
        assertEquals(damage,15);
        assertEquals(merlin.getResource(), initRes- 15);


    }

    @Test
    void testHealSpellNoMana() {

        Mage merlin = new Mage();
        merlin.setMana(10);
        int initRes = merlin.getResource();
        int damage = merlin.cast("Heal");
        assertEquals(damage,0);
        assertEquals(merlin.getResource(), initRes);
    }

    @Test
    void testHealSpellExact() {
        Mage merlin = new Mage();
        merlin.setMana(15);
        int damage = merlin.cast("Heal");
        assertEquals(merlin.getResource(), 0);
        assertEquals(damage,15);
    }

    @Test
    void testUnknownSpell() {
        Mage merlin = new Mage();
        int initRes = merlin.getResource();
        int damage = merlin.cast("Multiclonage");

        assertEquals(merlin.getResource(), initRes);
        assertEquals(damage,0);

    }

}