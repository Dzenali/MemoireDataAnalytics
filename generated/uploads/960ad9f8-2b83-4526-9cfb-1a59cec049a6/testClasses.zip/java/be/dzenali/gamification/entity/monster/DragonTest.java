package be.dzenali.gamification.entity.monster;

import be.dzenali.gamification.entity.archetype.Mage;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class DragonTest {

    @Test
    void testResource() {
        Dragon veldorack = new Dragon();

    }

}