package be.dzenali.gamification.item;

import be.dzenali.gamification.data.ArmorType;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.BeforeEach;

import static org.junit.Assert.*;

class ArmorTest {
        private Armor lightArmor;
        private Armor mediumArmor;
        private Armor heavyArmor;

        @BeforeEach
        void setUp() {
            lightArmor = new Armor(5, ArmorType.LIGHT, 100, 20);
            mediumArmor = new Armor(10, ArmorType.MEDIUM, 100, 50);
            heavyArmor = new Armor(15, ArmorType.HEAVY, 100, 80);
        }

        @Test
        void getArmorClass() {
            assertEquals(5, lightArmor.getArmorClass());
            assertEquals(10, mediumArmor.getArmorClass());
            assertEquals(15, heavyArmor.getArmorClass());
        }

        @Test
        void getArmorClassWhenIsBroken() {
            assertEquals(5, lightArmor.getArmorClass());
            assertEquals(10, mediumArmor.getArmorClass());
            assertEquals(15, heavyArmor.getArmorClass());

            lightArmor.updateDurability(-100);
            mediumArmor.updateDurability(-100);
            heavyArmor.updateDurability(-100);

            assertEquals(10, lightArmor.getArmorClass());
            assertEquals(10, mediumArmor.getArmorClass());
            assertEquals(10, heavyArmor.getArmorClass());
        }

        @Test
        void getArmorType() {
            assertEquals(ArmorType.LIGHT, lightArmor.getArmorType());
            assertEquals(ArmorType.MEDIUM, mediumArmor.getArmorType());
            assertEquals(ArmorType.HEAVY, heavyArmor.getArmorType());
        }

        @Test
        void damageDurability() {
            assertEquals(100, lightArmor.getDurability());
            assertEquals(100, mediumArmor.getDurability());
            assertEquals(100, heavyArmor.getDurability());

            lightArmor.damageDurability(20);
            mediumArmor.damageDurability(20);
            heavyArmor.damageDurability(20);

            assertEquals((int)(100+20*0.5), lightArmor.getDurability());
            assertEquals((int)(100+20*0.8), mediumArmor.getDurability());
            assertEquals((int)(100+20*1.5), heavyArmor.getDurability());
        }

        @Test
        void getArmorClassDexBonusCap() {
            assertEquals(5, lightArmor.getArmorClassDexBonusCap());
            assertEquals(3, mediumArmor.getArmorClassDexBonusCap());
            assertEquals(0, heavyArmor.getArmorClassDexBonusCap());
        }

        @Test
        void toStringTest() {
            String expectedLight = "damage: 5, durability: 100, armor type: LIGHT, value: 20";
            String expectedMedium = "damage: 10, durability: 100, armor type: MEDIUM, value: 50";
            String expectedHeavy = "damage: 15, durability: 100, armor type: HEAVY, value: 80";

            assertEquals(expectedLight, lightArmor.toString());
            assertEquals(expectedMedium, mediumArmor.toString());
            assertEquals(expectedHeavy, heavyArmor.toString());
        }
}