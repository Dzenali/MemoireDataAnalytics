package be.dzenali.gamification.item;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.BeforeEach;

import static org.junit.Assert.*;

class EquipmentTest {
    private Equipment equipment;

    @BeforeEach
    void setUp() {
        equipment = new Equipment(100, 50);
    }

    @Test
    void getEquipementValue() {
        assertEquals(50, equipment.getValue());
    }

    @Test
    void getDurability() {
        assertEquals(100,equipment.getDurability());
    }

    @Test
    void getMaxDurability() {
        assertEquals(100,equipment.getMaxDurability());
    }

    @Test
    void updateDurabilityWithPositiveValue() {
        assertEquals(100,equipment.getDurability());
        equipment.updateDurability(20);
        assertEquals(100,equipment.getMaxDurability());
        assertEquals(120,equipment.getDurability());
    }

    @Test
    void updateDurabilityWithNegativeValue() {
        assertEquals(100,equipment.getDurability());
        equipment.updateDurability(-20);
        assertEquals(100,equipment.getMaxDurability());
        assertEquals(80,equipment.getDurability());
    }

    @Test
    void updateDurabilityWithZeroValue() {
        assertEquals(100,equipment.getDurability());
        equipment.updateDurability(0);
        assertEquals(100,equipment.getMaxDurability());
        assertEquals(100,equipment.getDurability());
    }

    @Test
    void updateDurabilityToDecreaseToZero() {
        assertEquals(100,equipment.getDurability());
        equipment.updateDurability(-100);
        assertEquals(100,equipment.getMaxDurability());
        assertEquals(0,equipment.getDurability());
        assertTrue(equipment.isBroken());
    }


    @Test
    void isBrokenAtInit() {
        assertFalse(equipment.isBroken());
    }
}