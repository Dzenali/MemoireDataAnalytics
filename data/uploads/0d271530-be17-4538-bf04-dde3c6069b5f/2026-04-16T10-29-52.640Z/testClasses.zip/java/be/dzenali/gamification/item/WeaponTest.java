package be.dzenali.gamification.item;

import be.dzenali.gamification.data.WeaponType;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.Assert.assertEquals;

public class WeaponTest {
    private Weapon heavyWeapon;
    private Weapon lightWeapon;
    private Weapon longWeapon;
    private Weapon shortWeapon;
    private Weapon versatileWeapon;
    private Weapon rangeWeapon;
    private Weapon naturalWeapon;


    @BeforeEach
    void setUp() {
        heavyWeapon = new Weapon(15, WeaponType.HEAVY, 100, 80);
        lightWeapon = new Weapon(5, WeaponType.LIGHT, 100, 20);
        longWeapon = new Weapon(10, WeaponType.LONG, 100, 50);
        shortWeapon = new Weapon(8, WeaponType.SHORT, 100, 30);
        versatileWeapon = new Weapon(12, WeaponType.VERSATILE, 100, 60);
        rangeWeapon = new Weapon(20, WeaponType.RANGE, 100, 90);
        naturalWeapon = new Weapon(7, WeaponType.NATURAL, 100, 40);
    }

    @Test
    void getWeaponDamage(){
        assertEquals(15, heavyWeapon.getWeaponDamage());
        assertEquals(5, lightWeapon.getWeaponDamage());
        assertEquals(10, longWeapon.getWeaponDamage());
        assertEquals(8, shortWeapon.getWeaponDamage());
        assertEquals(12, versatileWeapon.getWeaponDamage());
        assertEquals(20, rangeWeapon.getWeaponDamage());
        assertEquals(7, naturalWeapon.getWeaponDamage());
    }

    @Test
    void getWeaponDamageWhenIsBroken(){
        assertEquals(15, heavyWeapon.getWeaponDamage());
        assertEquals(5, lightWeapon.getWeaponDamage());
        assertEquals(10, longWeapon.getWeaponDamage());
        assertEquals(8, shortWeapon.getWeaponDamage());
        assertEquals(12, versatileWeapon.getWeaponDamage());
        assertEquals(20, rangeWeapon.getWeaponDamage());
        assertEquals(7, naturalWeapon.getWeaponDamage());

        heavyWeapon.updateDurability(-100);
        lightWeapon.updateDurability(-100);
        longWeapon.updateDurability(-100);
        shortWeapon.updateDurability(-100);
        versatileWeapon.updateDurability(-100);
        rangeWeapon.updateDurability(-100);
        naturalWeapon.updateDurability(-100);

        assertEquals(0, heavyWeapon.getWeaponDamage());
        assertEquals(0, lightWeapon.getWeaponDamage());
        assertEquals(0, longWeapon.getWeaponDamage());
        assertEquals(0, shortWeapon.getWeaponDamage());
        assertEquals(0, versatileWeapon.getWeaponDamage());
        assertEquals(0, rangeWeapon.getWeaponDamage());
        assertEquals(0, naturalWeapon.getWeaponDamage());
    }

    @Test
    void getWeaponType() {
        assertEquals(WeaponType.HEAVY, heavyWeapon.getWeaponType());
        assertEquals(WeaponType.LIGHT, lightWeapon.getWeaponType());
        assertEquals(WeaponType.LONG, longWeapon.getWeaponType());
        assertEquals(WeaponType.SHORT, shortWeapon.getWeaponType());
        assertEquals(WeaponType.VERSATILE, versatileWeapon.getWeaponType());
        assertEquals(WeaponType.RANGE, rangeWeapon.getWeaponType());
        assertEquals(WeaponType.NATURAL, naturalWeapon.getWeaponType());
    }

    @Test
    void damageDurability(){
        assertEquals(100, heavyWeapon.getDurability());
        assertEquals(100, lightWeapon.getDurability());
        assertEquals(100, longWeapon.getDurability());
        assertEquals(100, shortWeapon.getDurability());
        assertEquals(100, versatileWeapon.getDurability());
        assertEquals(100, rangeWeapon.getDurability());
        assertEquals(100, naturalWeapon.getDurability());

        heavyWeapon.damageDurability(-20);
        lightWeapon.damageDurability(-20);
        longWeapon.damageDurability(-20);
        shortWeapon.damageDurability(-20);
        versatileWeapon.damageDurability(-20);
        rangeWeapon.damageDurability(-20);
        naturalWeapon.damageDurability(-20);

        assertEquals(80, heavyWeapon.getDurability());
        assertEquals(80, lightWeapon.getDurability());
        assertEquals(80, longWeapon.getDurability());
        assertEquals(80, shortWeapon.getDurability());
        assertEquals(80, versatileWeapon.getDurability());
        assertEquals(80, rangeWeapon.getDurability());
        assertEquals(80, naturalWeapon.getDurability());
    }

    @Test
    void getDamage(){
        assertEquals(100, heavyWeapon.getDurability());
        assertEquals(100, lightWeapon.getDurability());
        assertEquals(100, longWeapon.getDurability());
        assertEquals(100, shortWeapon.getDurability());
        assertEquals(100, versatileWeapon.getDurability());
        assertEquals(100, rangeWeapon.getDurability());
        assertEquals(100, naturalWeapon.getDurability());

        assertEquals(15, heavyWeapon.getDamage());
        assertEquals(5, lightWeapon.getDamage());
        assertEquals(10, longWeapon.getDamage());
        assertEquals(8, shortWeapon.getDamage());
        assertEquals(12, versatileWeapon.getDamage());
        assertEquals(20, rangeWeapon.getDamage());
        assertEquals(7, naturalWeapon.getDamage());

        assertEquals(115, heavyWeapon.getDurability());
        assertEquals(105, lightWeapon.getDurability());
        assertEquals(110, longWeapon.getDurability());
        assertEquals(108, shortWeapon.getDurability());
        assertEquals(112, versatileWeapon.getDurability());
        assertEquals(120, rangeWeapon.getDurability());
        assertEquals(107, naturalWeapon.getDurability());
    }

    @Test
    void toStringTest(){
        assertEquals("damage: 15, durability: 100, value: 80", heavyWeapon.toString());
        assertEquals("damage: 5, durability: 100, value: 20", lightWeapon.toString());
        assertEquals("damage: 10, durability: 100, value: 50", longWeapon.toString());
        assertEquals("damage: 8, durability: 100, value: 30", shortWeapon.toString());
        assertEquals("damage: 12, durability: 100, value: 60", versatileWeapon.toString());
        assertEquals("damage: 20, durability: 100, value: 90", rangeWeapon.toString());
        assertEquals("damage: 7, durability: 100, value: 40", naturalWeapon.toString());
    }

}