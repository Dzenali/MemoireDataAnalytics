package be.dzenali.gamification.entity;

import be.dzenali.gamification.data.Aggressivity;
import be.dzenali.gamification.data.StatBlock;
import be.dzenali.gamification.data.StatType;
import org.junit.Test;

import static org.junit.Assert.*;

public class MonsterTest {
    @Test
    public void shouldCreateMonsterTest() {
        StatBlock stats = new StatBlock(1, 1, 1, 1, 1, 1);
        Monster monster = new Monster("Jérôme", 1, stats, 1, 1, Aggressivity.LOW, 1);
        assertEquals("Jérôme", monster.getName());
        assertEquals((int)(1 * Aggressivity.LOW.getMultiplier()), monster.getAttackDmg(), 0.01);
        assertEquals((int) (1 / Aggressivity.LOW.getMultiplier()), monster.getArmorClass());
        assertEquals(Aggressivity.LOW, monster.getAggressivity());
        assertEquals(1, monster.getExp());
        assertEquals(stats, monster.getStatBlock());
        assertEquals(1, monster.getStat(StatType.CHARISMA));
        assertEquals(1, monster.getStat(StatType.CONSTITUTION));
        assertEquals(1, monster.getStat(StatType.DEXTERITY));
        assertEquals(1, monster.getStat(StatType.INTELLIGENCE));
        assertEquals(1, monster.getStat(StatType.WISDOM));
        assertEquals(1, monster.getStat(StatType.STRENGTH));
        assertTrue(monster.isAlive());
    }

    @Test
    public void shouldChangeAggressivityTest() {
        StatBlock stats = new StatBlock(1, 1, 1, 1, 1, 1);
        Monster monster = new Monster("Jérôme", 1, stats, 1, 1, Aggressivity.LOW, 1);
        monster.changeAggressivity(Aggressivity.HIGH);
        assertEquals(Aggressivity.HIGH, monster.getAggressivity());
    }

    @Test
    public void shouldStringifyCorrectly() {
        StatBlock stats = new StatBlock(1, 1, 1, 1, 1, 1);
        Monster monster = new Monster("Jérôme", 1, stats, 1, 1, Aggressivity.LOW, 1);
        assertEquals("Jérôme - HP: 1/1", monster.toString());
    }

    @Test
    public void shouldDie() {
        StatBlock stats = new StatBlock(1, 1, 1, 1, 1, 1);
        Monster monster = new Monster("Jérôme", 1, stats, 1, 1, Aggressivity.LOW, 1);
        monster.getHealthPoints().updateCurrentHP(-1);
        assertFalse(monster.isAlive());
    }
}