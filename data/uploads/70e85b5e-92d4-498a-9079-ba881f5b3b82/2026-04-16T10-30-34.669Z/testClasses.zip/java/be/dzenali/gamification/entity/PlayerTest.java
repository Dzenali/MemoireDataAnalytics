package be.dzenali.gamification.entity;

import be.dzenali.gamification.data.ArmorType;
import be.dzenali.gamification.data.StatBlock;
import be.dzenali.gamification.data.StatType;
import be.dzenali.gamification.data.WeaponType;
import be.dzenali.gamification.item.Armor;
import be.dzenali.gamification.item.Item;
import be.dzenali.gamification.item.Weapon;
import org.junit.Test;

import java.util.ArrayList;

import static org.junit.Assert.assertEquals;

public class PlayerTest {
    @Test
    public void shouldCreatePlayer() {
        StatBlock stats = new StatBlock(1, 1, 1, 1, 1, 1);
        Armor armor = new Armor(1, ArmorType.LIGHT, 1, 1);
        Weapon weapon = new Weapon(1, WeaponType.SHORT, 1, 1);
        ArrayList<Item> equipment = new ArrayList<>();
        Player player = new Player("Gianni", 1, stats, armor, weapon, equipment);
        assertEquals("Gianni", player.getName());
        assertEquals(stats.get(StatType.DEXTERITY), player.getStat(StatType.DEXTERITY));
        assertEquals(stats.get(StatType.CHARISMA), player.getStat(StatType.CHARISMA));
        assertEquals(stats.get(StatType.CONSTITUTION), player.getStat(StatType.CONSTITUTION));
        assertEquals(stats.get(StatType.INTELLIGENCE), player.getStat(StatType.INTELLIGENCE));
        assertEquals(stats.get(StatType.STRENGTH), player.getStat(StatType.STRENGTH));
        assertEquals(stats.get(StatType.WISDOM), player.getStat(StatType.WISDOM));
        assertEquals(1, player.getLevel());
        assertEquals(1, player.getArmorClass());
        assertEquals(armor, player.getArmor());
        assertEquals(weapon, player.getWeapon());
        assertEquals(0, player.getExperience());
        assertEquals(equipment, player.getEquipment());
    }
}