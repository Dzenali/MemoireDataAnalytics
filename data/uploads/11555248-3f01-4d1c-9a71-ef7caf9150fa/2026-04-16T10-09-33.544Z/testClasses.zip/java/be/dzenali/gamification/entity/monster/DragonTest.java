package be.dzenali.gamification.entity.monster;

import org.junit.Test;


import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertThat;

public class DragonTest {

    @Test
    public void testFlyDragonAttackDMG() {
        Dragon drake = new Dragon();

        //expected damage
        int expected = 72;

        //damage
        int degt = drake.getAttackDmg();

        assertEquals(expected,degt);
    }

    @Test
    public void testflyDragonArmor() {
        Dragon drake = new Dragon();

        //expected damage
        int expected = 10;

        //armor (armor / 2
        int armor = drake.getArmorClass();

        assertEquals(expected,armor);
    }
    @Test
    public void testflyDragon() {
        Dragon drake = new Dragon();

        //expected damage
        boolean expected = true;

        //armor (armor / 2
        boolean flying = drake.canFly();

        assertEquals(expected,flying);
    }
    @Test
    public void testGroundDragon() {
        //set wounded beast
        Dragon vouivre = new Dragon();
        int maxpv = vouivre.getHealthPoints().getMaxHP();
        int wound = maxpv-1;
        vouivre.getHealthPoints().updateCurrentHP(wound);

        //expected damage
        boolean expected = false;

        //armor (armor / 2
        boolean flying = vouivre.canFly();

        assertEquals(expected,flying);
    }

    @Test
    public void testWound() {
        //set wounded beast
        Dragon vouivre = new Dragon();
        int maxpv = vouivre.getHealthPoints().getMaxHP();
        //int wound = maxpv-1;
        //vouivre.getHealthPoints().updateCurrentHP(wound);

        //expected damage
        boolean expected = 100;

        //armor (armor / 2
        //boolean flying = vouivre.canFly();

        assertEquals(expected,maxpv);
    }



}