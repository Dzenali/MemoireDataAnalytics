package be.dzenali.gamification.entity.monster;

import be.dzenali.gamification.data.Aggressivity;
import org.junit.Test;

import static org.junit.Assert.*;

public class OrkTest {

    @Test
    public void testInitialState() {
        Ork ork = new Ork();
        assertEquals("Ork", ork.getName());
        assertEquals(400, ork.getExp());
        assertEquals(Aggressivity.MEDIUM, ork.getAggressivity());
        assertFalse(ork.ironWillIsActive());
    }

    @Test
    public void testOrkHp() {
        Ork ork = new Ork();
        // CON 14 * level 3 = 42
        assertEquals(42, ork.getHealthPoints().getMaxHP());
        assertEquals(42, ork.getHealthPoints().getCurrentHP());
    }

    @Test
    public void testOrkAttackDmg_WithoutIronWill() {
        Ork ork = new Ork();
        // attack 12 * MEDIUM 1.0 = 12
        assertEquals(12, ork.getAttackDmg());
    }

    @Test
    public void testOrkArmorClass_WithoutIronWill() {
        Ork ork = new Ork();
        // armorClass 12 / MEDIUM 1.0 = 12
        assertEquals(12, ork.getArmorClass());
    }

    @Test
    public void testIronWill_TogglesState() {
        Ork ork = new Ork();
        assertFalse(ork.ironWillIsActive());
        ork.ironWill();
        assertTrue(ork.ironWillIsActive());
        ork.ironWill();
        assertFalse(ork.ironWillIsActive());
    }

    @Test
    public void testIronWill_IncreasesArmorClassByExactlySix() {
        Ork ork = new Ork();
        int normalAC = ork.getArmorClass();
        ork.ironWill();
        assertEquals(normalAC + 6, ork.getArmorClass());
        assertEquals(18, ork.getArmorClass()); // 12 + 6
    }

    @Test
    public void testIronWill_IncreasesAttackDmgByExactlyThree() {
        Ork ork = new Ork();
        int normalAtk = ork.getAttackDmg();
        ork.ironWill();
        assertEquals(normalAtk + 3, ork.getAttackDmg());
        assertEquals(15, ork.getAttackDmg()); // 12 + 3
    }

    @Test
    public void testIronWill_Deactivated_ResetsArmorClass() {
        Ork ork = new Ork();
        ork.ironWill(); // activate
        ork.ironWill(); // deactivate
        assertEquals(12, ork.getArmorClass());
    }

    @Test
    public void testIronWill_Deactivated_ResetsAttackDmg() {
        Ork ork = new Ork();
        ork.ironWill(); // activate
        ork.ironWill(); // deactivate
        assertEquals(12, ork.getAttackDmg());
    }

    @Test
    public void testOrkIsAlive() {
        Ork ork = new Ork();
        assertTrue(ork.isAlive());
        ork.getHealthPoints().updateCurrentHP(-100);
        assertFalse(ork.isAlive());
    }
}
