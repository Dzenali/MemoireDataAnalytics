package be.dzenali.gamification;

import be.dzenali.gamification.data.Aggressivity;
import be.dzenali.gamification.entity.archetype.Mage;
import be.dzenali.gamification.entity.archetype.Rogue;
import be.dzenali.gamification.entity.archetype.Warrior;
import be.dzenali.gamification.entity.monster.Dragon;
import be.dzenali.gamification.entity.monster.Goblin;
import be.dzenali.gamification.entity.monster.Ork;
import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.*;

public class CombatRulesTest {

    private CombatRules rules;

    @Before
    public void setUp() {
        rules = new CombatRules();
    }

    @Test
    public void computeDamageTest() {}

    // --- Player attacks Monster ---

    @Test
    public void testComputeDamage_Warrior_vs_Goblin_Medium() {
        Warrior warrior = new Warrior();
        Goblin goblin = new Goblin();
        // attackScore = weapon(18) + STR(16)/4 = 18 + 4 = 22
        // defense (MEDIUM bonus 0) = goblinAC(5) + 0 = 5
        // damage = max(22 - 5, 0) = 17
        assertEquals(17, rules.computeDamage(warrior, goblin));
    }

    @Test
    public void testComputeDamage_Warrior_vs_Goblin_Low() {
        Warrior warrior = new Warrior();
        Goblin goblin = new Goblin();
        goblin.changeAggressivity(Aggressivity.LOW);
        // goblinAC LOW = (int)(5/0.5) = 10; defense (LOW bonus 5) = 10 + 5 = 15
        // attackScore = 22; damage = max(22 - 15, 0) = 7
        assertEquals(7, rules.computeDamage(warrior, goblin));
    }

    @Test
    public void testComputeDamage_Warrior_vs_Goblin_High() {
        Warrior warrior = new Warrior();
        Goblin goblin = new Goblin();
        goblin.changeAggressivity(Aggressivity.HIGH);
        // goblinAC HIGH = (int)(5/2.0) = 2; defense (HIGH bonus -5) = 2 + (-5) = -3
        // attackScore = 22; damage = max(22 - (-3), 0) = 25
        assertEquals(25, rules.computeDamage(warrior, goblin));
    }

    @Test
    public void testComputeDamage_NeverNegative() {
        Mage mage = new Mage();
        Dragon dragon = new Dragon();
        int damage = rules.computeDamage(mage, dragon);
        assertTrue(damage >= 0);
    }

    // --- Monster attacks Player ---

    @Test
    public void testComputeDamage_Goblin_Medium_vs_Warrior() {
        Goblin goblin = new Goblin();
        Warrior warrior = new Warrior();
        // MEDIUM: attackScore = getAttackDmg()(5) + 5 = 10
        // defense = warriorAC(14)
        // damage = max(10 - 14, 0) = 0
        assertEquals(0, rules.computeDamage(goblin, warrior));
    }

    @Test
    public void testComputeDamage_Goblin_High_vs_Warrior() {
        Goblin goblin = new Goblin();
        goblin.changeAggressivity(Aggressivity.HIGH);
        Warrior warrior = new Warrior();
        // HIGH: attackScore = getAttackDmg()(10) + 10 = 20
        // defense = warriorAC(14)
        // damage = max(20 - 14, 0) = 6
        assertEquals(6, rules.computeDamage(goblin, warrior));
    }

    @Test
    public void testComputeDamage_Goblin_Low_vs_Warrior() {
        Goblin goblin = new Goblin();
        goblin.changeAggressivity(Aggressivity.LOW);
        Warrior warrior = new Warrior();
        // LOW: attackScore = getAttackDmg()(2)
        // defense = warriorAC(14)
        // damage = max(2 - 14, 0) = 0
        assertEquals(0, rules.computeDamage(goblin, warrior));
    }

    @Test
    public void testComputeDamage_MonsterNeverNegative() {
        Dragon dragon = new Dragon();
        Mage mage = new Mage();
        int damage = rules.computeDamage(dragon, mage);
        assertTrue(damage >= 0);
    }

    // --- Initiative ---

    @Test
    public void testCalculateInitiative_Warrior() {
        Warrior warrior = new Warrior();
        // DEX 14 → modifier = max(0, (14-5)/2) = max(0, 4) = 4
        // HEAVY armor penalty = 2
        // initiative = 4 - 2 = 2
        assertEquals(2, rules.calculateInitiative(warrior));
    }

    @Test
    public void testCalculateInitiative_Mage() {
        Mage mage = new Mage();
        // DEX 8 → modifier = max(0, (8-5)/2) = max(0, 1) = 1
        // LIGHT armor penalty = 0
        // initiative = 1 - 0 = 1
        assertEquals(1, rules.calculateInitiative(mage));
    }

    @Test
    public void testCalculateInitiative_Rogue() {
        Rogue rogue = new Rogue();
        // DEX 18 → modifier = max(0, (18-5)/2) = max(0, 6) = 6
        // LIGHT armor penalty = 0
        // initiative = 6 - 0 = 6
        assertEquals(6, rules.calculateInitiative(rogue));
    }

    @Test
    public void testCalculateInitiative_Goblin() {
        Goblin goblin = new Goblin();
        // DEX 4 → modifier = max(0, (4-5)/2) = max(0, 0) = 0
        assertEquals(0, rules.calculateInitiative(goblin));
    }

    @Test
    public void testCalculateInitiative_Ork() {
        Ork ork = new Ork();
        // DEX 12 → modifier = max(0, (12-5)/2) = max(0, 3) = 3
        assertEquals(3, rules.calculateInitiative(ork));
    }

    // --- Heal and InflictDamage ---

    @Test
    public void testHeal_IncreasesPlayerHP() {
        Warrior warrior = new Warrior();
        warrior.getHealthPoints().updateCurrentHP(-50);
        int hpBefore = warrior.getHealthPoints().getCurrentHP();
        rules.heal(warrior, 20);
        assertEquals(hpBefore + 20, warrior.getHealthPoints().getCurrentHP());
    }

    @Test
    public void testInflictDamage_Player_ReducesHP() {
        Warrior warrior = new Warrior();
        int hpBefore = warrior.getHealthPoints().getCurrentHP();
        rules.inflictDamage(warrior, 10);
        assertEquals(hpBefore - 10, warrior.getHealthPoints().getCurrentHP());
    }

    @Test
    public void testInflictDamage_Monster_ReducesHP() {
        Goblin goblin = new Goblin();
        int hpBefore = goblin.getHealthPoints().getCurrentHP();
        rules.inflictDamage(goblin, 2);
        assertEquals(hpBefore - 2, goblin.getHealthPoints().getCurrentHP());
    }

    @Test
    public void testInflictDamage_Monster_KillsIt() {
        Goblin goblin = new Goblin();
        assertTrue(goblin.isAlive());
        rules.inflictDamage(goblin, 100);
        assertFalse(goblin.isAlive());
    }
}
