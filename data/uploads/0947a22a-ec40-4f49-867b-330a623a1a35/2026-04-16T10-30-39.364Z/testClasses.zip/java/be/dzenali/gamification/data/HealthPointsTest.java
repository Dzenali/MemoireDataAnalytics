package be.dzenali.gamification.data;

import org.junit.Test;
import static org.junit.Assert.*;

public class HealthPointsTest {

    @Test
    public void testConstructor_Normal() {
        HealthPoints hp = new HealthPoints(5, 10);

        assertEquals(5, hp.getCurrentHP());
        assertEquals(10, hp.getMaxHP());
    }

    @Test
    public void testConstructor_MaxHPZero_ClampedToOne() {
        HealthPoints hp = new HealthPoints(5, 0);

        assertEquals(1, hp.getMaxHP());
        assertEquals(1, hp.getCurrentHP());
    }

    @Test
    public void testConstructor_MaxHPNegative_ClampedToOne() {
        HealthPoints hp = new HealthPoints(5, -5);

        assertEquals(1, hp.getMaxHP());
        assertEquals(1, hp.getCurrentHP());
    }

    @Test
    public void testConstructor_CurrentHPExceedsMax_ClampedToMax() {
        HealthPoints hp = new HealthPoints(15, 10);

        assertEquals(10, hp.getCurrentHP());
        assertEquals(10, hp.getMaxHP());
    }

    @Test
    public void testConstructor_CurrentHPZero_ClampedToOne() {
        HealthPoints hp = new HealthPoints(0, 10);

        assertEquals(1, hp.getCurrentHP());
        assertEquals(10, hp.getMaxHP());
    }

    @Test
    public void testConstructor_CurrentHPNegative_ClampedToOne() {
        HealthPoints hp = new HealthPoints(-5, 10);

        assertEquals(1, hp.getCurrentHP());
        assertEquals(10, hp.getMaxHP());
    }

    @Test
    public void testIncreasedBy_Normal() {
        HealthPoints base = new HealthPoints(5, 10);
        HealthPoints bonus = new HealthPoints(3, 5);

        HealthPoints result = base.increasedBy(bonus);

        assertEquals(8, result.getCurrentHP());
        assertEquals(15, result.getMaxHP());
    }

    @Test
    public void testIncreasedBy_DoesNotMutateOriginals() {
        HealthPoints base = new HealthPoints(5, 10);
        HealthPoints bonus = new HealthPoints(3, 5);

        base.increasedBy(bonus);

        assertEquals(5, base.getCurrentHP());
        assertEquals(10, base.getMaxHP());
    }

    @Test
    public void testUpdateCurrentHP_NormalIncrease() {
        HealthPoints hp = new HealthPoints(5, 10);

        int result = hp.updateCurrentHP(2.0);

        assertEquals(7, result);
        assertEquals(7, hp.getCurrentHP());
    }

    @Test
    public void testUpdateCurrentHP_IncreaseExceedsMax_ClampedToMax() {
        HealthPoints hp = new HealthPoints(5, 10);

        int result = hp.updateCurrentHP(10.0);

        assertEquals(10, result);
        assertEquals(10, hp.getCurrentHP());
    }

    @Test
    public void testUpdateCurrentHP_IncreaseToExactlyMax() {
        HealthPoints hp = new HealthPoints(8, 10);

        int result = hp.updateCurrentHP(2.0);

        assertEquals(10, result);
        assertEquals(10, hp.getCurrentHP());
    }

    @Test
    public void testUpdateCurrentHP_NormalDecrease() {
        HealthPoints hp = new HealthPoints(5, 10);

        int result = hp.updateCurrentHP(-2.0);

        assertEquals(3, result);
        assertEquals(3, hp.getCurrentHP());
    }

    @Test
    public void testUpdateCurrentHP_DecreaseBelowOne_SetToZero() {
        HealthPoints hp = new HealthPoints(1, 10);

        int result = hp.updateCurrentHP(-5.0);

        assertEquals(0, result);
        assertEquals(0, hp.getCurrentHP());
    }

    @Test
    public void testUpdateCurrentHP_DecimalAmountTruncated() {
        HealthPoints hp = new HealthPoints(5, 10);

        int result = hp.updateCurrentHP(1.9);

        assertEquals(6, result);
    }
}
