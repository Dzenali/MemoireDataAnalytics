package be.dzenali.gamification.data;

import org.junit.Test;
import static org.junit.Assert.*;

public class StatBlockTest {

    @Test
    public void testConstructor_Normal() {
        StatBlock sb = new StatBlock(10, 12, 14, 8, 16, 11);

        assertEquals(10, sb.get(StatType.STRENGTH));
        assertEquals(12, sb.get(StatType.DEXTERITY));
        assertEquals(14, sb.get(StatType.CONSTITUTION));
        assertEquals(8,  sb.get(StatType.INTELLIGENCE));
        assertEquals(16, sb.get(StatType.WISDOM));
        assertEquals(11, sb.get(StatType.CHARISMA));
    }

    @Test
    public void testConstructor_BoundaryMin_OneIsStored() {
        StatBlock sb = new StatBlock(1, 1, 1, 1, 1, 1);

        assertEquals(1, sb.get(StatType.STRENGTH));
        assertEquals(1, sb.get(StatType.CHARISMA));
    }

    @Test
    public void testConstructor_BoundaryMax_EighteenIsStored() {
        StatBlock sb = new StatBlock(18, 18, 18, 18, 18, 18);

        assertEquals(18, sb.get(StatType.STRENGTH));
        assertEquals(18, sb.get(StatType.CHARISMA));
    }

    @Test
    public void testConstructor_BelowMin_ClampedToOne() {
        StatBlock sb = new StatBlock(0, -5, 1, 1, 1, 1);

        assertEquals(1, sb.get(StatType.STRENGTH));
        assertEquals(1, sb.get(StatType.DEXTERITY));
    }

    @Test
    public void testConstructor_AboveMax_ClampedToEighteen() {
        StatBlock sb = new StatBlock(19, 25, 1, 1, 1, 1);

        assertEquals(18, sb.get(StatType.STRENGTH));
        assertEquals(18, sb.get(StatType.DEXTERITY));
    }

    @Test
    public void testIncrease_Normal() {
        StatBlock sb = new StatBlock(10, 10, 10, 10, 10, 10);

        sb.increase(StatType.STRENGTH);

        assertEquals(11, sb.get(StatType.STRENGTH));
    }

    @Test
    public void testIncrease_OnlyTargetStatChanges() {
        StatBlock sb = new StatBlock(10, 10, 10, 10, 10, 10);

        sb.increase(StatType.DEXTERITY);

        assertEquals(10, sb.get(StatType.STRENGTH));
        assertEquals(11, sb.get(StatType.DEXTERITY));
        assertEquals(10, sb.get(StatType.CONSTITUTION));
        assertEquals(10, sb.get(StatType.INTELLIGENCE));
        assertEquals(10, sb.get(StatType.WISDOM));
        assertEquals(10, sb.get(StatType.CHARISMA));
    }

    @Test
    public void testIncrease_MultipleTimesUp_ToTwenty() {
        StatBlock sb = new StatBlock(18, 10, 10, 10, 10, 10);

        sb.increase(StatType.STRENGTH); // 19
        sb.increase(StatType.STRENGTH); // 20

        assertEquals(20, sb.get(StatType.STRENGTH));
    }

    @Test
    public void testIncrease_AtTwenty_NoEffect() {
        StatBlock sb = new StatBlock(18, 10, 10, 10, 10, 10);

        sb.increase(StatType.STRENGTH);
        sb.increase(StatType.STRENGTH);
        sb.increase(StatType.STRENGTH);
        assertEquals(20, sb.get(StatType.STRENGTH));
    }

    @Test
    public void testIncrease_AllStats() {
        StatBlock sb = new StatBlock(10, 10, 10, 10, 10, 10);

        for (StatType type : StatType.values()) {
            sb.increase(type);
        }

        for (StatType type : StatType.values()) {
            assertEquals(11, sb.get(type));
        }
    }
}
