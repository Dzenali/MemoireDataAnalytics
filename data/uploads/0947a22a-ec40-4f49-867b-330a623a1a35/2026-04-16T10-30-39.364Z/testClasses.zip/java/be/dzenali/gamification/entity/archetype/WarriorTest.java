package be.dzenali.gamification.entity.archetype;

import be.dzenali.gamification.data.StatType;
import org.junit.Test;
import static org.junit.Assert.*;

public class WarriorTest {

    @Test
    public void testInitialState() {
        Warrior warrior = new Warrior();

        assertEquals("Warrior", warrior.getName());
        assertEquals(0, warrior.getResource());
        assertEquals(16, warrior.getStat(StatType.STRENGTH));
    }

    @Test
    public void testAttack_IncreasesRageByTen() {
        Warrior warrior = new Warrior();

        warrior.attack();

        assertEquals(10, warrior.getResource());
    }

    @Test
    public void testWhirlWind_WithEnoughRage_ReducesRageAndReturnsDamage() {
        Warrior warrior = new Warrior();

        warrior.attack(); // 10 rage
        warrior.attack(); // 20 rage
        warrior.attack(); // 30 rage

        int dmg = warrior.useWhirlWind();

        assertTrue(dmg > 0);
        assertEquals(0, warrior.getResource());
    }

}
