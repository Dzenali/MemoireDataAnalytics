package be.dzenali.gamification.entity.archetype;

import be.dzenali.gamification.data.StatType;
import org.junit.Test;
import static org.junit.Assert.*;

public class MageTest {

    @Test
    public void testInitialState() {
        Mage mage = new Mage();

        assertEquals("Mage", mage.getName());
        assertEquals(300, mage.getResource());
        assertEquals(18, mage.getStat(StatType.INTELLIGENCE));
    }

    @Test
    public void testCast_FireBall_ReturnsDamageAndConsumesMana() {
        Mage mage = new Mage();

        int dmg = mage.cast("FireBall");

        assertEquals(65, dmg);
        assertEquals(270, mage.getResource());
    }

    @Test
    public void testCast_NotEnoughMana_ReturnsZero() {
        Mage mage = new Mage();
        mage.setMana(0);

        int result = mage.cast("FireBall");

        assertEquals(0, result);
        assertEquals(0, mage.getResource());
    }

}
