package be.dzenali.gamification.data;

import org.junit.Test;
import static org.junit.Assert.*;

public class CoordsTest {

    private static final double DELTA = 0.0001;

    @Test
    public void testCoordsConstruction() {
        Coords coords = new Coords(5.0, 10.0);

        assertEquals(5.0, coords.getX(), DELTA);
        assertEquals(10.0, coords.getY(), DELTA);
    }

    @Test
    public void testCoordsConstructionWithNegativeValues() {
        Coords coords = new Coords(-3.5, -7.2);

        assertEquals(-3.5, coords.getX(), DELTA);
        assertEquals(-7.2, coords.getY(), DELTA);
    }

    @Test
    public void testCoordsConstructionWithZero() {
        Coords coords = new Coords(0.0, 0.0);

        assertEquals(0.0, coords.getX(), DELTA);
        assertEquals(0.0, coords.getY(), DELTA);
    }

    @Test
    public void testSetX() {
        Coords coords = new Coords(1.0, 2.0);

        coords.setX(15.5);
        assertEquals(15.5, coords.getX(), DELTA);
        assertEquals(2.0, coords.getY(), DELTA);
    }

    @Test
    public void testSetY() {
        Coords coords = new Coords(1.0, 2.0);

        coords.setY(25.7);
        assertEquals(1.0, coords.getX(), DELTA);
        assertEquals(25.7, coords.getY(), DELTA);
    }

    @Test
    public void testGetDistanceTo_SamePoint() {
        Coords point1 = new Coords(3.0, 4.0);
        Coords point2 = new Coords(3.0, 4.0);

        assertEquals(0.0, point1.getDistanceTo(point2), DELTA);
    }

    @Test
    public void testGetDistanceTo_HorizontalDistance() {
        Coords point1 = new Coords(0.0, 0.0);
        Coords point2 = new Coords(3.0, 0.0);

        assertEquals(3.0, point1.getDistanceTo(point2), DELTA);
    }

    @Test
    public void testGetDistanceTo_VerticalDistance() {
        Coords point1 = new Coords(0.0, 0.0);
        Coords point2 = new Coords(0.0, 4.0);

        assertEquals(4.0, point1.getDistanceTo(point2), DELTA);
    }

    @Test
    public void testGetDistanceTo_DiagonalDistance() {
        Coords point1 = new Coords(0.0, 0.0);
        Coords point2 = new Coords(3.0, 4.0);

        assertEquals(5.0, point1.getDistanceTo(point2), DELTA);
    }

    @Test
    public void testGetDistanceTo_NegativeCoordinates() {
        Coords point1 = new Coords(-1.0, -1.0);
        Coords point2 = new Coords(-4.0, -5.0);

        assertEquals(5.0, point1.getDistanceTo(point2), DELTA);
    }

    @Test
    public void testGetAngleTo_PositiveXDirection() {
        Coords point1 = new Coords(0.0, 0.0);
        Coords point2 = new Coords(1.0, 0.0);

        assertEquals(0.0, point1.getAngleTo(point2), DELTA);
    }

    @Test
    public void testGetAngleTo_PositiveYDirection() {
        Coords point1 = new Coords(0.0, 0.0);
        Coords point2 = new Coords(0.0, 1.0);

        double expectedAngle = Math.toDegrees(Math.atan2(1.0, 0.0));
        assertEquals(expectedAngle, point1.getAngleTo(point2), DELTA);
    }

    @Test
    public void testGetAngleTo_DiagonalDirection() {
        Coords point1 = new Coords(0.0, 0.0);
        Coords point2 = new Coords(1.0, 1.0);

        // deltaX = 1, deltaY = 1
        double expectedAngle = Math.toDegrees(Math.atan2(1.0, 1.0));
        assertEquals(expectedAngle, point1.getAngleTo(point2), DELTA);
    }

    @Test
    public void testGetAngleTo_SamePoint() {
        Coords point1 = new Coords(5.0, 5.0);
        Coords point2 = new Coords(5.0, 5.0);

        // deltaX = 0, deltaY = 10 (5 + 5)
        double expectedAngle = Math.toDegrees(Math.atan2(10.0, 0.0));
        assertEquals(expectedAngle, point1.getAngleTo(point2), DELTA);
    }

    @Test
    public void testMove_PositiveOffset() {
        Coords coords = new Coords(5.0, 10.0);

        coords.move(2.0, 3.0);

        assertEquals(7.0, coords.getX(), DELTA); // x + x Offset
        assertEquals(7.0, coords.getY(), DELTA); // y - y Offset (10 - 3)
    }

    @Test
    public void testMove_NegativeOffset() {
        Coords coords = new Coords(5.0, 10.0);

        coords.move(-2.0, -3.0);

        assertEquals(3.0, coords.getX(), DELTA); // 5 + (-2)
        assertEquals(13.0, coords.getY(), DELTA); // 10 - (-3) = 10 + 3
    }

    @Test
    public void testMove_ZeroOffset() {
        Coords coords = new Coords(5.0, 10.0);

        coords.move(0.0, 0.0);

        assertEquals(5.0, coords.getX(), DELTA);
        assertEquals(10.0, coords.getY(), DELTA);
    }

    @Test
    public void testMove_MultipleMovements() {
        Coords coords = new Coords(0.0, 0.0);

        coords.move(1.0, 1.0);
        assertEquals(1.0, coords.getX(), DELTA);
        assertEquals(-1.0, coords.getY(), DELTA);

        coords.move(2.0, -1.0);
        assertEquals(3.0, coords.getX(), DELTA);
        assertEquals(0.0, coords.getY(), DELTA); // -1 - (-1) = 0
    }

    @Test
    public void testMove_DecimalValues() {
        Coords coords = new Coords(1.5, 2.7);

        coords.move(0.5, 0.3);

        assertEquals(2.0, coords.getX(), DELTA);
        assertEquals(2.4, coords.getY(), DELTA); // 2.7 - 0.3
    }

    @Test
    public void testComplexScenario() {
        Coords start = new Coords(0.0, 0.0);
        Coords end = new Coords(3.0, 4.0);

        // Test distance
        assertEquals(5.0, start.getDistanceTo(end), DELTA);

        // Move start point
        start.move(1.0, 1.0);
        assertEquals(1.0, start.getX(), DELTA);
        assertEquals(-1.0, start.getY(), DELTA);

        // Test new distance
        double newDistance = start.getDistanceTo(end);
        double expected = Math.sqrt(Math.pow(3.0 - 1.0, 2) + Math.pow(4.0 - (-1.0), 2));
        assertEquals(expected, newDistance, DELTA);
    }
}