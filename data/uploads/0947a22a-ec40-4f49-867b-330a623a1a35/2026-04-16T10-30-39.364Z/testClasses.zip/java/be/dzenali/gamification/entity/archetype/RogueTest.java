package be.dzenali.gamification.entity.archetype;

import be.dzenali.gamification.data.Aggressivity;
import be.dzenali.gamification.data.StatBlock;
import be.dzenali.gamification.data.StatType;
import be.dzenali.gamification.entity.Monster;
import org.junit.Test;
import static org.junit.Assert.*;

public class RogueTest {

    @Test
    public void testInitialState() {
        Rogue rogue = new Rogue();

        assertEquals("Rogue", rogue.getName());
        assertEquals(100, rogue.getRessource());
        assertEquals(18, rogue.getStat(StatType.DEXTERITY));
    }

    @Test
    public void testShadowClone_ReturnsDoubleWeaponDamage() {
        Rogue rogue = new Rogue();

        int result = rogue.shadowClone();

        assertEquals(40, result);
    }

    @Test
    public void testExecute_LowHealthMonster_ReturnsCurrentHP() {
        Rogue rogue = new Rogue();
        Monster monster = new Monster("Goblin", 10,
                new StatBlock(10, 10, 18, 10, 10, 10),
                5, 10, Aggressivity.MEDIUM, 50);
        // maxHP = 18*10 = 180 → threshold = 18 → set HP to 10
        monster.getHealthPoints().updateCurrentHP(-170);

        int result = rogue.execute(monster);

        assertEquals(10, result);
    }

}
