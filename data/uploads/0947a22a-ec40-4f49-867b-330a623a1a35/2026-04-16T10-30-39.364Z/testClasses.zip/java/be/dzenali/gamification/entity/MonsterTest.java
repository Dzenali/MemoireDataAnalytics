package be.dzenali.gamification.entity;

import be.dzenali.gamification.data.Aggressivity;
import be.dzenali.gamification.data.StatType;
import be.dzenali.gamification.entity.monster.Goblin;
import be.dzenali.gamification.entity.monster.Ork;
import org.junit.Test;

import static org.junit.Assert.*;

public class MonsterTest {

    @Test
    public void testIsAlive_Initially() {
        Goblin goblin = new Goblin();
        assertTrue(goblin.isAlive());
    }

    @Test
    public void testIsAlive_AfterLethalDamage() {
        Goblin goblin = new Goblin();
        goblin.getHealthPoints().updateCurrentHP(-100);
        assertFalse(goblin.isAlive());
    }

    @Test
    public void testIsAlive_AtOneHP() {
        Goblin goblin = new Goblin();
        goblin.getHealthPoints().updateCurrentHP(-3); // 4 → 1
        assertTrue(goblin.isAlive());
        assertEquals(1, goblin.getHealthPoints().getCurrentHP());
    }

    @Test
    public void testChangeAggressivity_UpdatesField() {
        Goblin goblin = new Goblin();
        assertEquals(Aggressivity.MEDIUM, goblin.getAggressivity());
        goblin.changeAggressivity(Aggressivity.HIGH);
        assertEquals(Aggressivity.HIGH, goblin.getAggressivity());
        goblin.changeAggressivity(Aggressivity.LOW);
        assertEquals(Aggressivity.LOW, goblin.getAggressivity());
    }

    @Test
    public void testGetAttackDmg_AllAggressivities() {
        Goblin goblin = new Goblin();
        // MEDIUM: (int)(5 * 1.0) = 5
        assertEquals(5, goblin.getAttackDmg());
        goblin.changeAggressivity(Aggressivity.LOW);
        // LOW: (int)(5 * 0.5) = 2
        assertEquals(2, goblin.getAttackDmg());
        goblin.changeAggressivity(Aggressivity.HIGH);
        // HIGH: (int)(5 * 2.0) = 10
        assertEquals(10, goblin.getAttackDmg());
    }

    @Test
    public void testGetArmorClass_AllAggressivities() {
        Goblin goblin = new Goblin();
        // MEDIUM: (int)(5 / 1.0) = 5
        assertEquals(5, goblin.getArmorClass());
        goblin.changeAggressivity(Aggressivity.LOW);
        // LOW: (int)(5 / 0.5) = 10
        assertEquals(10, goblin.getArmorClass());
        goblin.changeAggressivity(Aggressivity.HIGH);
        // HIGH: (int)(5 / 2.0) = 2
        assertEquals(2, goblin.getArmorClass());
    }

    @Test
    public void testGetExp_DifferentMonsters() {
        Goblin goblin = new Goblin();
        assertEquals(50, goblin.getExp());
        Ork ork = new Ork();
        assertEquals(400, ork.getExp());
    }

    @Test
    public void testGetStat() {
        Goblin goblin = new Goblin();
        assertEquals(6, goblin.getStat(StatType.STRENGTH));
        assertEquals(4, goblin.getStat(StatType.DEXTERITY));
        assertEquals(4, goblin.getStat(StatType.CONSTITUTION));
    }
}
