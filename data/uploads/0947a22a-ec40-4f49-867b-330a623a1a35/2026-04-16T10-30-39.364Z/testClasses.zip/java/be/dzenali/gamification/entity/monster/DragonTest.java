package be.dzenali.gamification.entity.monster;

import be.dzenali.gamification.data.Aggressivity;
import org.junit.Test;

import static org.junit.Assert.*;

public class DragonTest {

    @Test
    public void testInitialState() {
        Dragon dragon = new Dragon();
        assertEquals("Dragon", dragon.getName());
        assertEquals(5000, dragon.getExp());
        assertEquals(Aggressivity.HIGH, dragon.getAggressivity());
    }

    @Test
    public void testDragonHp() {
        Dragon dragon = new Dragon();
        // CON 20 clamped to 18 by StatBlock, level 15 → HP = 18 * 15 = 270
        assertEquals(270, dragon.getHealthPoints().getMaxHP());
        assertEquals(270, dragon.getHealthPoints().getCurrentHP());
    }

    @Test
    public void testDragonCanFly_Initially() {
        Dragon dragon = new Dragon();
        // At full HP (270), can fly since 270 >= 270/2 = 135
        assertTrue(dragon.canFly());
    }

    @Test
    public void testDragonCanFly_AtExactHalfHP() {
        Dragon dragon = new Dragon();
        dragon.getHealthPoints().updateCurrentHP(-135); // 270 - 135 = 135
        // 135 >= 135, still flying
        assertTrue(dragon.canFly());
        assertEquals(135, dragon.getHealthPoints().getCurrentHP());
    }

    @Test
    public void testDragonCannotFly_BelowHalfHP() {
        Dragon dragon = new Dragon();
        dragon.getHealthPoints().updateCurrentHP(-136); // 270 - 136 = 134
        // 134 < 135, grounded
        assertFalse(dragon.canFly());
    }

    @Test
    public void testDragonAttackDmg_Flying() {
        Dragon dragon = new Dragon();
        // super.getAttackDmg() = (int)(36 * HIGH 2.0) = 72, dragon is flying
        assertEquals(72, dragon.getAttackDmg());
    }

    @Test
    public void testDragonAttackDmg_Grounded() {
        Dragon dragon = new Dragon();
        dragon.getHealthPoints().updateCurrentHP(-136); // below half HP
        // grounded: (int)(72 * 0.5) = 36
        assertEquals(36, dragon.getAttackDmg());
    }

    @Test
    public void testDragonArmorClass_Flying() {
        Dragon dragon = new Dragon();
        // super.getArmorClass() = (int)(20 / HIGH 2.0) = 10, dragon is flying
        assertEquals(10, dragon.getArmorClass());
    }

    @Test
    public void testDragonArmorClass_Grounded() {
        Dragon dragon = new Dragon();
        dragon.getHealthPoints().updateCurrentHP(-136); // below half HP
        // grounded: (int)(10 * 1.5) = 15
        assertEquals(15, dragon.getArmorClass());
    }

    @Test
    public void testDragonIsAlive() {
        Dragon dragon = new Dragon();
        assertTrue(dragon.isAlive());
        dragon.getHealthPoints().updateCurrentHP(-400);
        assertFalse(dragon.isAlive());
    }
}
