package be.dzenali.gamification.entity;

import be.dzenali.gamification.data.StatType;
import be.dzenali.gamification.entity.archetype.Mage;
import be.dzenali.gamification.entity.archetype.Rogue;
import be.dzenali.gamification.entity.archetype.Warrior;
import org.junit.Test;

import static org.junit.Assert.*;

public class PlayerTest {

    @Test
    public void testInitialLevel_IsOne() {
        Warrior warrior = new Warrior();
        assertEquals(1, warrior.getLevel());
    }

    @Test
    public void testInitialExperience_IsZero() {
        Warrior warrior = new Warrior();
        assertEquals(0, warrior.getExperience());
    }

    @Test
    public void testGainExperience_Accumulates() {
        Warrior warrior = new Warrior();
        warrior.gainExperience(50);
        assertEquals(50, warrior.getExperience());
        warrior.gainExperience(100);
        assertEquals(150, warrior.getExperience());
    }

    @Test
    public void testLevelUp_IncrementsLevel() {
        Warrior warrior = new Warrior();
        warrior.levelUp(StatType.STRENGTH);
        assertEquals(2, warrior.getLevel());
    }

    @Test
    public void testLevelUp_IncreasesStat() {
        Warrior warrior = new Warrior();
        int strBefore = warrior.getStat(StatType.STRENGTH);
        warrior.levelUp(StatType.STRENGTH);
        assertEquals(strBefore + 1, warrior.getStat(StatType.STRENGTH));
    }

    @Test
    public void testIsAlive_Initially() {
        Warrior warrior = new Warrior();
        assertTrue(warrior.isAlive());
    }

    @Test
    public void testIsAlive_AfterLethalDamage() {
        Warrior warrior = new Warrior();
        warrior.getHealthPoints().updateCurrentHP(-1000);
        assertFalse(warrior.isAlive());
    }

    @Test
    public void testIsAlive_AtOneHP() {
        Warrior warrior = new Warrior();
        // HP = CON(15) * 8 = 120; reduce by 119 to leave 1
        warrior.getHealthPoints().updateCurrentHP(-119);
        assertTrue(warrior.isAlive());
        assertEquals(1, warrior.getHealthPoints().getCurrentHP());
    }

    @Test
    public void testGetArmorClass_Warrior() {
        Warrior warrior = new Warrior();
        // ChainVest AC 14, HEAVY armor dexBonusCap 0, DEX 14
        // armorClass = 14 + min(14/5, 0) = 14 + 0 = 14
        assertEquals(14, warrior.getArmorClass());
    }

    @Test
    public void testGetArmorClass_Rogue() {
        Rogue rogue = new Rogue();
        // Gabison AC 12, LIGHT armor dexBonusCap 5, DEX 18
        // armorClass = 12 + min(18/5, 5) = 12 + min(3, 5) = 12 + 3 = 15
        assertEquals(15, rogue.getArmorClass());
    }

    @Test
    public void testGetArmorClass_Mage() {
        Mage mage = new Mage();
        // Pajama AC 4, LIGHT armor dexBonusCap 5, DEX 8
        // armorClass = 4 + min(8/5, 5) = 4 + min(1, 5) = 4 + 1 = 5
        assertEquals(5, mage.getArmorClass());
    }

    @Test
    public void testGetStat_WarriorStrength() {
        Warrior warrior = new Warrior();
        assertEquals(16, warrior.getStat(StatType.STRENGTH));
    }

    @Test
    public void testSetName() {
        Warrior warrior = new Warrior();
        warrior.setName("Conan");
        assertEquals("Conan", warrior.getName());
    }

    @Test
    public void testWarriorHP() {
        Warrior warrior = new Warrior();
        // CON 15 * healthModifier 8 = 120
        assertEquals(120, warrior.getHealthPoints().getMaxHP());
        assertEquals(120, warrior.getHealthPoints().getCurrentHP());
    }

    @Test
    public void testMageHP() {
        Mage mage = new Mage();
        // CON 10 * healthModifier 3 = 30
        assertEquals(30, mage.getHealthPoints().getMaxHP());
    }

    @Test
    public void testRogueHP() {
        Rogue rogue = new Rogue();
        // CON 12 * healthModifier 1 = 12
        assertEquals(12, rogue.getHealthPoints().getMaxHP());
    }
}
