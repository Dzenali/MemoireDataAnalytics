package be.dzenali.gamification.entity.monster;

import be.dzenali.gamification.data.Aggressivity;
import be.dzenali.gamification.data.StatType;
import org.junit.Test;

import static org.junit.Assert.*;

public class GoblinTest {

    @Test
    public void testInitialState() {
        Goblin goblin = new Goblin();
        assertEquals("Goblin", goblin.getName());
        assertEquals(50, goblin.getExp());
        assertEquals(Aggressivity.MEDIUM, goblin.getAggressivity());
    }

    @Test
    public void testGoblinHp() {
        Goblin goblin = new Goblin();
        // CON 4 * level 1 = 4
        assertEquals(4, goblin.getHealthPoints().getMaxHP());
        assertEquals(4, goblin.getHealthPoints().getCurrentHP());
    }

    @Test
    public void testGoblinStats() {
        Goblin goblin = new Goblin();
        assertEquals(6, goblin.getStat(StatType.STRENGTH));
        assertEquals(4, goblin.getStat(StatType.DEXTERITY));
        assertEquals(4, goblin.getStat(StatType.CONSTITUTION));
    }

    @Test
    public void testGoblinAttackDmg_Medium() {
        Goblin goblin = new Goblin();
        // attack 5 * MEDIUM multiplier 1.0 = 5
        assertEquals(5, goblin.getAttackDmg());
    }

    @Test
    public void testGoblinArmorClass_Medium() {
        Goblin goblin = new Goblin();
        // armorClass 5 / MEDIUM multiplier 1.0 = 5
        assertEquals(5, goblin.getArmorClass());
    }

    @Test
    public void testGoblinIsAlive_Initially() {
        Goblin goblin = new Goblin();
        assertTrue(goblin.isAlive());
    }

    @Test
    public void testGoblinIsAlive_AfterLethalDamage() {
        Goblin goblin = new Goblin();
        goblin.getHealthPoints().updateCurrentHP(-100);
        assertFalse(goblin.isAlive());
    }

    @Test
    public void testGoblinIsAlive_AtOneHp() {
        Goblin goblin = new Goblin();
        goblin.getHealthPoints().updateCurrentHP(-3); // 4 - 3 = 1
        assertTrue(goblin.isAlive());
        assertEquals(1, goblin.getHealthPoints().getCurrentHP());
    }

    @Test
    public void testGoblinAttackDmg_LowAggressivity() {
        Goblin goblin = new Goblin();
        goblin.changeAggressivity(Aggressivity.LOW);
        // attack 5 * LOW multiplier 0.5 = 2 (int truncation)
        assertEquals(2, goblin.getAttackDmg());
    }

    @Test
    public void testGoblinArmorClass_LowAggressivity() {
        Goblin goblin = new Goblin();
        goblin.changeAggressivity(Aggressivity.LOW);
        // armorClass 5 / LOW multiplier 0.5 = 10
        assertEquals(10, goblin.getArmorClass());
    }

    @Test
    public void testGoblinAttackDmg_HighAggressivity() {
        Goblin goblin = new Goblin();
        goblin.changeAggressivity(Aggressivity.HIGH);
        // attack 5 * HIGH multiplier 2.0 = 10
        assertEquals(10, goblin.getAttackDmg());
    }

    @Test
    public void testGoblinArmorClass_HighAggressivity() {
        Goblin goblin = new Goblin();
        goblin.changeAggressivity(Aggressivity.HIGH);
        // armorClass 5 / HIGH multiplier 2.0 = 2
        assertEquals(2, goblin.getArmorClass());
    }
}
