package be.dzenali.gamification.data;

import org.junit.Test;

import static org.junit.Assert.assertEquals;

public class HealthPointsTest {

    // --------------------
    // CONSTRUCTEUR
    // --------------------

    @Test
    public void testConstructorNormal() {
        HealthPoints hp = new HealthPoints(5, 10);
        assertEquals(5, hp.getCurrentHP());
        assertEquals(10, hp.getMaxHP());
    }

    @Test
    public void testMaxHpNegative() {
        HealthPoints hp = new HealthPoints(5, -10);
        assertEquals(1, hp.getMaxHP());
    }

    @Test
    public void testCurrentGreaterThanMax() {
        HealthPoints hp = new HealthPoints(20, 10);
        assertEquals(10, hp.getCurrentHP());
        assertEquals(10, hp.getMaxHP());
    }

    @Test
    public void testCurrentNegative() {
        HealthPoints hp = new HealthPoints(-5, 10);
        assertEquals(1, hp.getCurrentHP());
    }

    // --------------------
    // increasedBy
    // --------------------

    @Test
    public void testIncreasedBy() {
        HealthPoints hp1 = new HealthPoints(5, 10);
        HealthPoints hp2 = new HealthPoints(3, 7);

        HealthPoints result = hp1.increasedBy(hp2);

        assertEquals(8, result.getCurrentHP());
        assertEquals(17, result.getMaxHP());
    }

    // --------------------
    // updateCurrentHP
    // --------------------

    @Test
    public void testUpdateNormal() {
        HealthPoints hp = new HealthPoints(5, 10);
        hp.updateCurrentHP(3);
        assertEquals(8, hp.getCurrentHP());
    }

    @Test
    public void testUpdateAboveMax() {
        HealthPoints hp = new HealthPoints(8, 10);
        hp.updateCurrentHP(5);
        assertEquals(10, hp.getCurrentHP());
    }

    @Test
    public void testUpdateBelowZero() {
        HealthPoints hp = new HealthPoints(5, 10);
        hp.updateCurrentHP(-10);
        assertEquals(0, hp.getCurrentHP());
    }

    @Test
    public void testUpdateWithDoubleTruncation() {
        HealthPoints hp = new HealthPoints(5, 10);
        hp.updateCurrentHP(2.7);
        assertEquals(7, hp.getCurrentHP()); // 2.7 -> 2
    }
}

