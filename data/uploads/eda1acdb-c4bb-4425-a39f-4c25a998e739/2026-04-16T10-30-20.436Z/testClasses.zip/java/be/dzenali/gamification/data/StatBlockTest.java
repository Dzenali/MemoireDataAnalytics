package be.dzenali.gamification.data;

import org.junit.Test;

import static org.junit.Assert.assertEquals;

public class StatBlockTest {

    @Test
    public void testInitializationClampsMin() {
        StatBlock sb = new StatBlock(-5, 0, 10, 10, 10, 10);

        assertEquals(1, sb.get(StatType.STRENGTH));
        assertEquals(1, sb.get(StatType.DEXTERITY));
    }

    @Test
    public void testInitializationClampsMax() {
        StatBlock sb = new StatBlock(25, 30, 10, 10, 10, 10);

        assertEquals(18, sb.get(StatType.STRENGTH));
        assertEquals(18, sb.get(StatType.DEXTERITY));
    }

    @Test
    public void testInitializationNormalValue() {
        StatBlock sb = new StatBlock(10, 12, 13, 14, 15, 16);

        assertEquals(10, sb.get(StatType.STRENGTH));
        assertEquals(16, sb.get(StatType.CHARISMA));
    }



}

