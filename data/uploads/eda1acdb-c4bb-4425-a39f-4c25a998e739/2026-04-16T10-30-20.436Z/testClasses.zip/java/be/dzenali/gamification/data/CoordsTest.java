package be.dzenali.gamification.data;

import org.junit.Test;

import static org.junit.Assert.assertEquals;

public class CoordsTest {

    // --------------------
    // DISTANCE
    // --------------------

    @Test
    public void testDistanceSamePoint() {
        Coords c = new Coords(1, 1);
        assertEquals(0.0, c.getDistanceTo(new Coords(1, 1)), 1e-9);
    }

    @Test
    public void testDistanceSimple() {
        Coords c = new Coords(0, 0);
        assertEquals(5.0, c.getDistanceTo(new Coords(3, 4)), 1e-9);
    }


    // --------------------
    // ANGLE
    // --------------------

    @Test
    public void testAngleRight() {
        Coords c = new Coords(0, 0);
        assertEquals(0.0, c.getAngleTo(new Coords(1, 0)), 1e-9);
    }

    @Test
    public void testAngleUp() {
        Coords c = new Coords(0, 0);
        double angle = c.getAngleTo(new Coords(0, 1));

        // dépend du bug de ton code (deltaY = otherY + thisY)
        assertEquals(90.0, angle, 1e-9);
    }

    @Test
    public void testAngleLeft() {
        Coords c = new Coords(0, 0);
        double angle = c.getAngleTo(new Coords(-1, 0));

        assertEquals(180.0, angle, 1e-9);
    }

    // --------------------
    // MOVE
    // --------------------

    @Test
    public void testMovePositive() {
        Coords c = new Coords(1, 1);
        c.move(2, 3);

        assertEquals(3.0, c.getX(), 1e-9);
        assertEquals(-2.0, c.getY(), 1e-9);
    }

    @Test
    public void testMoveNegative() {
        Coords c = new Coords(5, 5);
        c.move(-2, -3);

        assertEquals(3.0, c.getX(), 1e-9);
        assertEquals(8.0, c.getY(), 1e-9);
    }
}


